// TEST bản T1–T8 (phương án B) — chạy: node test5.js
const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');
const s = html.indexOf('<script>'), e = html.indexOf('</script>');
let code = html.slice(s + 8, e);

// stub DOM tối thiểu để eval được cả file
const el = () => ({ innerHTML: '', value: '', scrollTop: 0, scrollHeight: 0, style: {}, dataset: {},
                    addEventListener() {}, querySelectorAll: () => [], appendChild() {}, focus() {} });
global.document = { getElementById: el, querySelector: el, querySelectorAll: () => [],
                    addEventListener() {}, body: el(), createElement: el };
global.window = { scrollTo() {}, addEventListener() {}, matchMedia: () => ({ matches: false, addEventListener() {} }),
                  location: { href: '' }, navigator: { serviceWorker: { register: () => Promise.resolve() } } };
global.navigator = window.navigator;
global.localStorage = { getItem: () => null, setItem() {}, removeItem() {} };
global.fetch = () => Promise.reject(new Error('no net'));

code += `;Object.assign(globalThis,{NV,TN,NVKHO,DET,KN,SC,VDATA,VTONG,MONTHS,MONTHS_CUM,MPARTIAL,
  DMONTHS,DMONTHS_CUM,VMONTHS,VMONTHS_CUM,V_CRITS,CRIT_TN,CRIT_TN_EXT,FORCE_PASS,FORCE_FAIL,
  detVal,detTotal,monthsPass,monthGrid,svgTrend,vCell,vMonth,vTotal,ptFor,mkCell,khoOf,vRec,
  profileHTML,leaderboardHTML,managerHTML,rulesHTML,homeHTML,localAnswer,login,S,medal,nvOfKho});`;
eval(code);

let pass = 0, fail = 0; const errs = [];
const ck = (n, a, b) => { if (JSON.stringify(a) === JSON.stringify(b)) pass++; else { fail++; errs.push(`${n}: got ${JSON.stringify(a)} exp ${JSON.stringify(b)}`); } };
const ok = (n, c) => ck(n, !!c, true);

// ── 1. Khung tháng ────────────────────────────────────────────────
const BO = JSON.parse(fs.readFileSync('build_out.json', 'utf8'));
// số tháng đọc từ build_out.json để không phải sửa test mỗi kỳ
ck('MONTHS', JSON.stringify(MONTHS), JSON.stringify(BO.meta.months.map(m => 'T' + m)));
ck('MPARTIAL rỗng', MPARTIAL.length, 0);
ck('MONTHS_CUM = MONTHS', JSON.stringify(MONTHS_CUM), JSON.stringify(MONTHS));
ck('DMONTHS_CUM đủ số tháng', DMONTHS_CUM.length, MONTHS.length);
ck('VMONTHS_CUM đủ số tháng', VMONTHS_CUM.length, MONTHS.length);

// ── 2. Số lượng — SO VỚI build_out.json, KHÔNG hard-code (tránh test lỗi thời)
const CHOT_BO = new Set((BO.CHOT6T || []).filter(m => BO.NV[m]));
// 22/09/2026: 'bảo lưu 6 tháng' KHÔNG còn giữ danh hiệu — VT chỉ theo quota điểm lũy kế.
const VT_BO = new Set(Object.keys(BO.NV).filter(m => BO.NV[m].vt_round));
ck('NV = build_out', NV.length, Object.keys(BO.NV).length);
ck('TN = build_out', TN.length, Object.keys(BO.TN).length);
const LAST = BO.meta.tnHangThang, TCTU = BO.meta.truongCaTu;
ck('tnHangThang = tháng cuối', LAST, +MONTHS[MONTHS.length - 1].slice(1));
ck('NVKHO = build_out', NVKHO.length, Object.keys(BO.TAIKHO).length);
ck('Vượt Trội = build_out', NV.filter(n => n.vuotTroi).length, VT_BO.size);
ck('Giữ chốt 6T = build_out', NV.filter(n => n.chot6t).length, CHOT_BO.size);
ck('VT tại kho = build_out', NVKHO.filter(n => n.vuotTroi).length,
   Object.values(BO.TAIKHO).filter(x => x.vuotTroi).length);
ck('Đủ ĐK = build_out', NV.filter(n => n.duDK).length,
   Object.values(BO.NV).filter(x => x.duDieuKien).length);
// từng người phải khớp tuyệt đối với build_out
NV.forEach(n => {
  ck(`VT ${n.ma} khớp build_out`, !!n.vuotTroi, VT_BO.has(n.ma));
  ck(`điểm ${n.ma} khớp build_out`, n.diem, BO.NV[n.ma].diem);
});

// ── 3. NV: điểm lũy kế = tổng điểm T1–T8 ─────────────────────────
NV.forEach(n => {
  const sum = MONTHS_CUM.reduce((a, m) => a + (n.thang[m] ? n.thang[m].diem : 0), 0);
  ck(`NV ${n.ma} diem=Σtháng`, n.diem, sum);
  const lk = ['khieuNai','tiepCan','xldd'].reduce((a,c)=>a+(n.diemLK[c]||0),0);
  ck(`NV ${n.ma} diemLK=diem`, lk, n.diem);
  ck(`NV ${n.ma} soThang`, n.soThang, Object.keys(n.thang).length);
  ck(`NV ${n.ma} duDK`, n.duDK, Object.keys(n.thang).length >= 5);
  Object.entries(n.thang).forEach(([m, mm]) => {
    const d = mm.tc.khieuNai.d + mm.tc.tiepCan.d + mm.tc.xldd.d;
    ck(`NV ${n.ma} ${m} điểm ô`, mm.diem, d);
    ok(`NV ${n.ma} ${m} điểm ≤6`, mm.diem <= 6);
  });
});

// ── 4. Xếp hạng trong kho (thi đấu, đồng hạng) ───────────────────
const byKho = {};
NV.forEach(n => (byKho[n.kho] = byKho[n.kho] || []).push(n));
Object.entries(byKho).forEach(([k, mem]) => {
  mem.forEach(n => ck(`hạng ${n.ma}`, n.xepHang, 1 + mem.filter(x => x.diem > n.diem).length));
});

// ── 5. Quota 30% (làm tròn gần nhất) + bảo lưu chốt 6 tháng ──────
Object.entries(byKho).forEach(([k, mem]) => {
  const elig = mem.filter(x => x.duDK);
  const q = Math.round(elig.length * 0.3);
  const vt = mem.filter(x => x.vuotTroi);
  const chot = mem.filter(x => x.chot6t);
  // Không miễn trừ cho nhóm đã đạt 6 tháng: TỔNG số VT của kho phải nằm trong quota
  ok(`${k}: tổng VT ≤ quota`, vt.length <= q);
  ok(`${k}: VT đều đủ điều kiện`, vt.every(x => x.duDK));
  chot.filter(x => !x.vuotTroi).forEach(x =>
    ok(`${k}: ${x.ma} rớt vì thua điểm`, vt.every(y => y.diem >= x.diem)));
  vt.forEach(x => ok(`${k}: ${x.ma} VT phải đủ ĐK hoặc chốt6T`, x.duDK || x.chot6t));
  // Đơn điệu theo điểm: không ai đủ ĐK, điểm cao hơn 1 người VT-mới, mà lại trượt
  const lowVTnew = Math.min(...vt.filter(x => !x.chot6t).map(x => x.diem), Infinity);
  elig.filter(x => !x.vuotTroi).forEach(x =>
    ok(`${k}: ${x.ma} trượt nhưng điểm ≤ ngưỡng`, x.diem <= lowVTnew));
});
ok('Tổng VT < 30% toàn khu vực', NV.filter(n => n.vuotTroi).length / NV.length < 0.30);

// ── 6. TN: 6 tiêu chí, điểm & hạng ───────────────────────────────
const CT6 = ['5sao','dungHen','tayNghe','xldd','tho5s','scdv','doi1','trondoi'];
ck('CRIT_TN 6 tiêu chí', Object.keys(CRIT_TN).sort(), CT6.slice().sort());
ck('CRIT_TN_EXT = CRIT_TN', Object.keys(CRIT_TN_EXT).sort(), CT6.slice().sort());
ck('FORCE_PASS rỗng', FORCE_PASS.length, 0);
ck('FORCE_FAIL rỗng', FORCE_FAIL.length, 0);
ck('V_CRITS = số tiêu chí trong CRIT_TN', V_CRITS.length, Object.keys(CRIT_TN).length);
ok('V_CRITS không có banDon', !V_CRITS.some(x => x[0] === 'banDon'));
TN.forEach(t => {
  const sum = CT6.reduce((a, c) => a + (t.diemLK[c] || 0), 0);
  ck(`TN ${t.ma} tongDiem`, t.tongDiem, sum);
  MONTHS.forEach(m => {
    const mm = t.thang[m]; if (!mm) return;
    ck(`TN ${t.ma} ${m} tong`, mm.tong, CT6.reduce((a, c) => a + ((mm.tc[c] || {}).d || 0), 0));
    CT6.forEach(c => {
      const tc = mm.tc[c]; if (!tc) return;
      const base = { '5sao': 4, dungHen: 2, tayNghe: 2, xldd: 2, tho5s: 2, scdv: 2,
                     doi1: 2, trondoi: 2 }[c];
      const pt = ptFor(c, base, m);
      ok(`TN ${t.ma} ${m} ${c} điểm hợp lệ`, tc.d === 0 || tc.d === pt);
    });
  });
  const g = TN.filter(x => x.vung === t.vung);
  // 01/11/2026: xếp hạng CHUNG BẢNG theo ĐIỂM THÁNG CUỐI (diemXH), không theo lũy kế
  ck(`TN ${t.ma} xepHang`, t.xepHang, 1 + g.filter(x => x.diemXH > t.diemXH).length);
  ck(`TN ${t.ma} diemXH = tong T${LAST}`, t.diemXH, (t.thang['T' + LAST] || {}).tong);
  // Trưởng Ca chỉ chấm từ T10; QLDV chấm đủ kỳ
  const expT = t.chucVu === 'Trưởng Ca' ? MONTHS.filter(m => +m.slice(1) >= TCTU) : MONTHS;
  ck(`TN ${t.ma} số tháng chấm (${t.chucVu})`, Object.keys(t.thang).sort(), expT.slice().sort());
  ck(`TN ${t.ma} tuThang`, t.tuThang, t.chucVu === 'Trưởng Ca' ? TCTU : 1);
});
// cùng kho -> cùng điểm tháng cuối (tiêu chí là cấp kho)
Object.values(TN.reduce((a, t) => { (a[t.kho] = a[t.kho] || []).push(t); return a; }, {}))
  .forEach(g => g.forEach(t => ck(`cùng kho ${t.kho} cùng điểm T${LAST}`, t.diemXH, g[0].diemXH)));
ck('SCDV T6 = 2đ', ptFor('scdv', 2, 'T6'), 2);
ck('SCDV T7 = 4đ', ptFor('scdv', 2, 'T7'), 4);
ck('SCDV T6 = 2đ', ptFor('scdv', 2, 'T6'), 2);
MONTHS.filter(m => +m.slice(1) >= 7).forEach(m => ck(`SCDV ${m} = 4đ`, ptFor('scdv', 2, m), 4));

// ── 7. VDATA khớp điểm TN ────────────────────────────────────────
ck('VDATA 12 kho', Object.keys(VDATA).length, 12);
Object.entries(VDATA).forEach(([k, o]) => {
  ck(`VDATA ${k} 6 tiêu chí`, Object.keys(o).sort(), CT6.slice().sort());
  // Tiêu chí có thể THIẾU tháng khi Sheet chưa có data (T9/T10: XLDĐ1L trống;
  // doi1/trondoi chỉ xét từ T9). Yêu cầu: không thừa tháng, và mọi kho thiếu GIỐNG NHAU.
  CT6.filter(c => o[c]).forEach(c => {
    ck(`VDATA ${k}.${c} không thừa tháng`, Object.keys(o[c]).length <= MONTHS.length, true);
    ck(`VDATA ${k}.${c} số tháng == kho đầu`, Object.keys(o[c]).length,
       Object.keys(VDATA[Object.keys(VDATA)[0]][c] || {}).length);
  });
});
TN.forEach(t => MONTHS.forEach(m => {
  const mm = t.thang[m]; if (!mm) return;
  CT6.forEach(c => {
    const tc = mm.tc[c]; if (!tc) return;
    const rec = VDATA[t.kho][c][m];
    ck(`TN ${t.ma} ${m} ${c} khớp VDATA`, tc.d > 0, rec[2] === 'Đạt');
  });
}));

// ── 8. detVal / detTotal đọc DET đủ MỌI tháng ────────────────────
{
  const n = NV.find(x => MONTHS.every(m => x.thang[m]));
  ck('có NV đủ mọi tháng để test DET', !!n, true);
  MONTHS.forEach(m => {
    ck(`detVal ${n.ma} ${m} tiếp cận`, detVal(n, 0, m), n.thang[m].tc.tiepCan.kq);
    ck(`detVal ${n.ma} ${m} khiếu nại`, detVal(n, 1, m), n.thang[m].tc.khieuNai.kq);
    ck(`detVal ${n.ma} ${m} XLĐ`, detVal(n, 2, m), n.thang[m].tc.xldd.kq);
  });
  const vs = MONTHS.map(m => detVal(n, 0, m));
  ck(`detTotal ${n.ma} TB tiếp cận`, detTotal(n, 0), vs.reduce((a, v) => a + (v || 0), 0) / MONTHS.length);
  ck('detVal NV lạ trả null', detVal({ ma: '__X__' }, 0, 'T1'), null);
}

// ── 9. monthsPass / monthGrid ────────────────────────────────────
{
  const t = TN[0];
  CT6.forEach(c => {
    const mp = monthsPass(t, c);
    ck(`monthsPass ${t.ma} ${c}`, mp.length,
       MONTHS.filter(m => t.thang[m] && t.thang[m].tc[c] && t.thang[m].tc[c].d > 0).length);
  });
  const g = monthGrid(t, Object.keys(CRIT_TN_EXT), CRIT_TN_EXT, FORCE_PASS, FORCE_FAIL);
  ok('monthGrid có 8 cột tháng', MONTHS.every(m => g.includes(`>${m}<`)));
  ok('monthGrid không còn dấu *', !g.includes('*'));
  ok('monthGrid không có Bán Đơn', !g.includes('Bán Đơn'));
}

// ── 10. vMonth / vTotal (tab Vùng) ───────────────────────────────
// vTotal(t) đọc VDATA theo KHO -> là LŨY KẾ CỦA KHO, phải khớp TN đại diện kho (QLDV đủ kỳ)
const TNREP = {}; TN.forEach(t => { const k = t.kho;
  if (!TNREP[k] || (t.tuThang || 1) < (TNREP[k].tuThang || 1)) TNREP[k] = t; });
Object.entries(TNREP).forEach(([k, t]) => {
  ck(`TN đại diện kho ${k} chấm đủ kỳ`, t.tuThang, 1);
  ck(`vTotal kho ${k} = tongDiem đại diện`, vTotal(t).ds, t.tongDiem);
});
TN.forEach(t => {
  const v = vTotal(t);
  ck(`vTotal ${t.ma} = lũy kế kho`, v.ds, TNREP[t.kho].tongDiem);
  MONTHS.forEach(m => { const vm = vMonth(t, m);
    ok(`vMonth ${t.ma} ${m} ≤ số tiêu chí`, vm.n <= V_CRITS.length); });
});

// ── 11. NVKHO ────────────────────────────────────────────────────
{
  const byK = {};
  NVKHO.forEach(x => (byK[x.kho] = byK[x.kho] || []).push(x));
  ck('NVKHO 2 kho', Object.keys(byK).sort(), ['VDH_KHH_TK', 'VTB_DNA_TK']);
  Object.entries(byK).forEach(([k, mem]) => {
    mem.sort((a, b) => a.hangThuNhap - b.hangThuNhap);
    ck(`${k} hạng liên tục`, mem.map(x => x.hangThuNhap), mem.map((_, i) => i + 1));
    ck(`${k} số VT = round(30%)`, mem.filter(x => x.vuotTroi).length, Math.round(mem.length * 0.3));
    ok(`${k} VT là người top`, mem.filter(x => x.vuotTroi).every(x => x.hangThuNhap <= Math.round(mem.length * 0.3)));
  });
  ok('NVKHO không lẫn vào NV', !NVKHO.some(x => NV.some(n => n.ma === x.ma)));
}

// ── 12. KN (khiếu nại) khớp điểm ─────────────────────────────────
NV.forEach(n => {
  const l = KN[n.ma] || [];
  MONTHS.filter(m => +m.slice(1) >= 7).forEach(m => {   // T1–T6 đóng băng, không tính lại
    const mm = n.thang[m]; if (!mm) return;
    ck(`KN ${n.ma} ${m} khớp`, mm.tc.khieuNai.kq, l.filter(x => x.t === m).length);
    ck(`KN ${n.ma} ${m} điểm`, mm.tc.khieuNai.d, l.filter(x => x.t === m).length === 0 ? 2 : 0);
  });
});

// ── 13. Render các trang không lỗi ───────────────────────────────
const tryRender = (nm, fn) => { try { const h = fn(); ok(`render ${nm}`, typeof h === 'string' && h.length > 50); }
                                catch (err) { fail++; errs.push(`render ${nm}: ${err.message}`); } };
tryRender('home', homeHTML);
tryRender('rules', rulesHTML);
tryRender('leaderboard', () => { S.seg = 'NV'; return leaderboardHTML(); });
tryRender('leaderboard KHO', () => { S.seg = 'KHO'; return leaderboardHTML(); });
tryRender('manager', managerHTML);
[['nv', NV[0]], ['tn', TN[0]], ['nvkho', NVKHO[0]], ['kho', { kho: NV[0].kho, tinh: NV[0].tinh, vung: NV[0].vung }]]
  .forEach(([ty, data]) => tryRender('profile ' + ty, () => { S.user = { type: ty, data }; return profileHTML(); }));

// ── 14. Chat trả lời được ────────────────────────────────────────
{
  const uNV = { type: 'nv', data: NV[0] }, uTN = { type: 'tn', data: TN[0] }, uQL = { type: 'ql', data: { ten: 'X', ma: '25634' } };
  [['tiêu chí xét vượt trội là gì', uNV], ['em được bao nhiêu điểm', uNV], ['tháng 8 thế nào', uNV],
   ['vượt trội tháng 8', uNV], ['chi tiết khiếu nại', uNV], ['tháng 8 thế nào', uTN],
   ['cho anh kết quả tổng khu vực', uQL], ['kỳ nào chốt', uNV], ['app này là gì', uNV]]
  .forEach(([q, u]) => {
    try { const a = localAnswer(q, u); ok(`chat "${q}"`, a === null || typeof a === 'string'); }
    catch (err) { fail++; errs.push(`chat "${q}": ${err.message}`); }
  });
}

console.log(`PASS ${pass} / FAIL ${fail}`);
if (fail) { console.log(errs.slice(0, 40).join('\n')); process.exit(1); }
