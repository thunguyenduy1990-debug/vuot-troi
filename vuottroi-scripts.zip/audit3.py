#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GIAI ĐOẠN 3 — soát 6 tiêu chí TRƯỞNG NHÓM độc lập từ tab 5 + tab 9."""
import openpyxl, re, json
from collections import defaultdict
D = json.load(open('build_out.json', encoding='utf-8'))
wb = openpyxl.load_workbook('DATA.xlsx', data_only=True)
LOI = []
def err(x): LOI.append(x)
def kc(s):
    m = re.search(r'(VTB|VDH)_[A-Z]{3}', str(s or '')); return m.group(0) if m else None
def n(v):
    if v is None or v == '': return None
    if isinstance(v, (int, float)): return float(v)
    s = str(v).strip(); p = s.endswith('%')
    s = re.sub(r'[^\d.,-]', '', s)
    c, d = s.count(','), s.count('.')
    if c and d: s = s.replace(',', '') if s.rfind('.') > s.rfind(',') else s.replace('.', '').replace(',', '.')
    elif c: s = s.replace(',', '') if len(s.split(',')[-1]) == 3 else s.replace(',', '.')
    try: f = float(s)
    except ValueError: return None
    return f / 100 if p else f

# ── CHẤT LƯỢNG: T1–T9 tab "5. CHẤT LƯỢNG" · T10+ tab "CHẤT LƯỢNG NEW" ──
VD = defaultdict(dict); mac_dinh = 0
MAP_OLD = {'dungHen': (6, 7, 9), 'tayNghe': (12, 13, 15), 'xldd': (18, 19, 21),
           '5sao': (22, 23, 25), 'tho5s': (28, 29, 31)}
MAP_NEW = {'5sao': (7, 8, 10), 'dungHen': (11, 12, 14), 'tayNghe': (17, 18, 20),
           'tho5s': (23, 24, 26), 'xldd': (32, 33, 35)}
def doc(ws, ct, ck_, r0, MAP, ths):
    global mac_dinh
    cnt = 0
    for r in range(r0, ws.max_row + 1):
        mm = re.match(r'Tháng\s*(\d+)$', str(ws.cell(r, ct).value or '').strip())
        if not mm: continue
        mth = int(mm.group(1))
        if mth not in ths: continue
        k = kc(ws.cell(r, ck_).value)
        if not k: continue
        for c, (cq, cp, cd) in MAP.items():
            dg = str(ws.cell(r, cd).value or '').strip()
            if not dg:
                if c == 'xldd': dg = 'Đạt'; mac_dinh += 1          # chốt 25/10: thiếu data -> auto Đạt
                elif c in ('dungHen', 'tayNghe', 'tho5s') and mth <= 6: dg = 'Đạt'; mac_dinh += 1
                else: continue
            VD[k].setdefault(c, {})[mth] = 'Đạt' if dg.upper().startswith('ĐẠT') else 'Không đạt'
            cnt += 1
    return cnt
TO = [m for m in range(1, 11) if m <= 9]; TN_ = [m for m in range(1, 11) if m >= 10]
a = doc(wb[[n for n in wb.sheetnames if n.startswith('5. CHẤT LƯỢNG')][0]], 1, 3, 3, MAP_OLD, TO)
b = doc(wb[[n for n in wb.sheetnames if n.startswith('CHẤT LƯỢNG NEW')][0]], 2, 6, 5, MAP_NEW, TN_)
print(f"[8] CHẤT LƯỢNG: {a} ô (T1-T9) + {b} ô (T10) · ô mặc-định-có-điểm: {mac_dinh}")

# ── 1 ĐỔI 1 + BH TRỌN ĐỜI (từ T9) ──
for crit, dau in (('doi1', '7.. CL 1 ĐỔI 1'), ('trondoi', '8. CL BH TRỌN ĐỜI')):
    ws = wb[[n for n in wb.sheetnames if n.startswith(dau)][0]]
    for r in range(4, ws.max_row + 1):
        mth = ws.cell(r, 1).value
        if not isinstance(mth, (int, float)) or int(mth) < 9 or int(mth) > 10: continue
        k = kc(ws.cell(r, 3).value)
        if not k: continue
        dg = str(ws.cell(r, 11).value or '').strip()
        if dg: VD[k].setdefault(crit, {})[int(mth)] = 'Đạt' if dg.upper().startswith('ĐẠT') else 'Không đạt'
print(f"[9] 1 ĐỔI 1 + TRỌN ĐỜI: {sum(len(v.get('doi1',{})) for v in VD.values())} + {sum(len(v.get('trondoi',{})) for v in VD.values())} ô")

# ── SCDV (tab 9) ──
ws = wb[[n for n in wb.sheetnames if n.startswith('9.SỬA CHỮA')][0]]; nscdv = 0
for r in range(4, ws.max_row + 1):
    mth = ws.cell(r, 1).value
    if not isinstance(mth, (int, float)) or int(mth) > 10: continue
    k = kc(ws.cell(r, 3).value)
    if not k: continue
    dg = str(ws.cell(r, 19).value or '').upper()
    VD[k].setdefault('scdv', {})[int(mth)] = 'Đạt' if ('ĐẠT' in dg and 'CHƯA' not in dg) else 'Không đạt'
    nscdv += 1
print(f"[9b] SCDV: {nscdv} ô")

# ── so với app ──────────────────────────────────────────────────────
TRUONGCA_TU = 10        # Trưởng Ca chỉ đánh giá từ T10 (chốt 01/11)
nso = 0
for m, t in D['TN'].items():
    k = t['kho']
    mths = range(TRUONGCA_TU, 11) if t['chucVu'].strip() == 'Trưởng Ca' else range(1, 11)
    for mth in mths:
        app = t['thang'].get(f'T{mth}')
        for c in ('5sao','dungHen','tayNghe','xldd','tho5s','scdv','doi1','trondoi'):
            mine = VD.get(k, {}).get(c, {}).get(mth)
            a = app['tc'].get(c) if app else None
            if mine is None and a is None: continue
            if mine is None: err(f"{m} T{mth} {c}: app CÓ mà soát KHÔNG có"); continue
            if a is None: err(f"{m} T{mth} {c}: soát CÓ ({mine}) mà app KHÔNG có"); continue
            dat_app = a['d'] > 0
            nso += 1
            if dat_app != (mine == 'Đạt'): err(f"{m} T{mth} {c}: soát={mine} app={'Đạt' if dat_app else 'Không đạt'}")
# kiểm tra số tháng được chấm đúng theo chức vụ
for m, t in D['TN'].items():
    exp = 1 if t['chucVu'].strip() == 'Trưởng Ca' else 10
    got = len([x for x in t['thang']])
    if got != exp: err(f"{m} ({t['chucVu']}): chấm {got} tháng, phải {exp}")
print(f"[10] so {len(D['TN'])} TN × 8 tiêu chí = {nso} ô đã đối chiếu")
print()
print('LỖI GIAI ĐOẠN 3:', ('\n  - ' + '\n  - '.join(LOI[:40])) if LOI else 'KHÔNG CÓ ✅')
