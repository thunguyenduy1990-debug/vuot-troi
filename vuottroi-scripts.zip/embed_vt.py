#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NHÚNG vuottroi.json MỚI VÀO index.html (hằng VT_EMBED).

BẮT BUỘC chạy SAU add_tab10.py. Nếu bỏ bước này, web vẫn đúng (vì fetch
vuottroi.json trước) NHƯNG bản mở offline / xuất PDF sẽ hiện SỐ CŨ.

    python3 embed_vt.py [index.html] [vuottroi.json]
"""
import re, sys, os, json

HTML = sys.argv[1] if len(sys.argv) > 1 else 'index.html'
JSON_ = sys.argv[2] if len(sys.argv) > 2 else 'vuottroi.json'
for f in (HTML, JSON_):
    if not os.path.exists(f): sys.exit(f'THIẾU FILE: {f}')

html = open(HTML, encoding='utf-8').read()
new  = open(JSON_, encoding='utf-8').read().strip()
meta_new = json.loads(new)['meta']

m = re.search(r'const VT_EMBED\s*=\s*(\{.*?\});', html, re.S)
assert m, 'không tìm thấy hằng VT_EMBED trong index.html'
meta_old = json.loads(m.group(1))['meta']

html = html[:m.start()] + 'const VT_EMBED = ' + new + ';' + html[m.end():]
open(HTML, 'w', encoding='utf-8').write(html)

# kiểm tra lại sau khi ghi
chk = json.loads(re.search(r'const VT_EMBED\s*=\s*(\{.*?\});',
                           open(HTML, encoding='utf-8').read(), re.S).group(1))['meta']
assert chk == meta_new, 'GHI HỎNG: VT_EMBED sau khi thay không khớp vuottroi.json'

print(f"VT_EMBED: {meta_old['capNhat']} ({meta_old['vtNha']}+{meta_old['vtKho']} VT)"
      f"  →  {chk['capNhat']} ({chk['vtNha']}+{chk['vtKho']} VT)")
