# BỘ SCRIPT VƯỢT TRỘI — BHSC CE Vùng Trung Bộ + Duyên Hải

Chạy trọn gói, chỉ cần **DATA.xlsx** (file Google Sheet "VTB - DH DATA 2026" xuất ra .xlsx):

```bash
bash chay.sh                        # ngày chốt = hôm nay
VT_NGAY_CHOT=31/10/2026 bash chay.sh
VT_THANG_CUOI=10 bash chay.sh       # ép tháng cuối (mặc định TỰ NHẬN từ tab 9)
```

Chạy xong có sẵn:
- `app/index.html` + `app/sw.js` → đẩy repo **vuot-troi**
- `index.html` + `vuottroi.json` + `VUOT-TROI-2026.xlsx` + `DATA-NGUON-VUOT-TROI.xlsx` → đẩy repo **bhsc-ce-vtb-vdh-dashboard**
- `VUOT TROI 2026 - <N> THANG DAU NAM BHSC.xlsx` → gửi anh Thu

## TỰ NHẬN, không ghi cứng
| Thứ | Cách nhận |
|---|---|
| Tháng cuối | tháng lớn nhất có đủ 12 kho ở tab `9.SỬA CHỮA KHÁCH LẺ` |
| Tháng chưa có lương | tab `3.THU NHẬP` có tới tháng nào, tháng sau đó trở đi dùng "có-bất-kỳ-data" |
| Bảng CHẤT LƯỢNG | tháng nào có ở `5. CHẤT LƯỢNG` thì lấy bảng đó, còn lại lấy `CHẤT LƯỢNG NEW` |
| Tên tab | khớp theo TIỀN TỐ (`1.GYKN`, `4.XỬ LÝ DD1 LẦN`...) nên thêm hậu tố vẫn chạy |

## HẰNG SỐ KHOÁ (chỉ đổi khi anh Thu chốt lại)
`build.py`: `QUOTA_MODE='round'` · `SCDV_4D_TU=7` · `CL2_TU=9` · `MIN_MONTHS=5`
· `TRUONGCA_TU=10` · `BO_QLDV={'153917','170083','3177','39675','66577'}` · `TN_TAIKHO=set()`

## NHÓM TRƯỞNG NHÓM / QLDV / TRƯỞNG CA (chốt 01/11/2026)
- **Trưởng Nhóm = Quản Lý Dịch Vụ** (cùng một chức vụ), **Trưởng Ca** là chức vụ mới,
  **chấm cùng bộ 8 tiêu chí** nhưng **chỉ từ T10** (`TRUONGCA_TU`).
- Sheet `DANH SÁCH NHÂN SỰ` có **dòng trùng mã**: luôn **lấy DÒNG CUỐI** (khối anh Thu dán
  sau là bản đúng nhất). Ai từ Nhân Viên lên Trưởng Ca sẽ **RA khỏi nhóm NV** → quota kho
  của họ giảm theo, có thể làm người khác rớt Vượt Trội (phải nêu cho anh Thu, xem mục DỪNG LẠI).
- Phòng ban **BẢO HÀNH TẠI KHO**: **anh Thu chốt 02/11 — KHÔNG tính Vượt Trội**. Cả 5 QLDV /
  Trưởng ca Tại Kho (`153917 170083 3177 39675 66577`) **bỏ hẳn khỏi app/web**: không vào bảng
  Trưởng nhóm, cũng **không** vào nhóm nhân viên tại kho (xét thu nhập). `TN_TAIKHO = set()`.
  `build.py` có **assert chặn**: nếu file sau xuất hiện QLDV/Trưởng ca Tại Kho **mã mới** mà
  chưa có trong `BO_QLDV`/`TN_TAIKHO` thì script DỪNG — phải hỏi anh Thu, không âm thầm bỏ.
- **Xếp hạng CHUNG MỘT BẢNG mỗi vùng theo ĐIỂM LŨY KẾ, cao → thấp** (`TN_HANG_THEO='luyke'`,
  anh Thu chốt 02/11). Trưởng ca chỉ có T10 nên lũy kế thấp → **nằm cuối bảng, anh Thu đã
  biết và đồng ý**. Cột điểm tháng cuối vẫn hiện để tham khảo (`diemXH`).
  Đổi `TN_HANG_THEO` trong `build.py` sang `'thangcuoi'` là cả app + web đổi theo
  (`diemHang` là trường duy nhất app/web dùng để xếp hạng; `patch_app.py` sinh lại
  `tnDiemXH()` trong app theo đúng `meta.tnHangTheo`).
  Tiêu chí là **cấp kho** nên cùng kho thì **bằng điểm từng tháng, đồng hạng**.
  (01/11 từng chốt xếp theo điểm tháng cuối — 02/11 đã đổi lại thành lũy kế.)
- Bảng VẬN HÀNH theo tỉnh dùng `tnOfKho/tnOfTinh` (người có kỳ chấm dài nhất) làm đại diện
  kho — KHÔNG được dùng `TN.find(...)` nữa, nếu không sẽ lấy Trưởng ca (chỉ T10) và sai số.

## DỪNG LẠI VÀ HỎI ANH THU khi
1. `doichieu.py` báo **VƯỢT 30%**
2. Bất kỳ `audit*.py` báo lỗi, hoặc `test_app.js` có FAIL
3. Tab đổi tên/đổi số cột (các `assert` sẽ chặn) — xem bảng cột trong `build.py`
4. Có người **đang làm** mà MẤT Vượt Trội → nêu rõ nguyên nhân để anh duyệt

## QUOTA 30% — LUẬT CHỐT 03/11/2026 (thay toàn bộ luật cũ)

```python
def quota30(n):            # n = TỔNG NHÂN SỰ của kho
    t = 3 * n              # 30% × n, đơn vị 1/10 suất
    return t // 10 + (1 if t % 10 >= 6 else 0)
```
- **Mẫu số là TỔNG NHÂN SỰ KHO**, KHÔNG phải chỉ người đủ điều kiện. (Trước 02/11 dùng
  người đủ ĐK — đã BỎ.)
- **Thập phân ≥ 0,6 → làm tròn LÊN · ≤ 0,5 → làm tròn XUỐNG.** Vd 15 người → 4,5 → **4 suất**;
  13 → 3,9 → **4**; 6 → 1,8 → **2**; 5 → 1,5 → **1**.
- **Trần = số người đủ ĐK.** Quota lớn hơn số người đủ ĐK thì `build.py` in ⚠️ và chỉ lấy tối đa
  số người đủ ĐK — **PHẢI HỎI ANH THU** có lấy thêm người chưa đủ 5 tháng hay không,
  KHÔNG tự quyết.
- Áp **cho cả** NV bảo hành tại nhà **và** NV bảo hành tại kho (`quota30` dùng ở 2 chỗ).
- Cột **Vượt Trội TỪNG THÁNG** trong `gen_vuottroi_json.py` **vẫn giữ `round()`** vì đã verify
  798/798 ô khớp file gốc anh Thu — đừng đổi nếu anh không yêu cầu.
- ⚠️ **TUYỆT ĐỐI KHÔNG dùng `round(n*0.30)`**: Python làm tròn về số CHẴN và `15*0.30` trong
  float ra `4.4999…`, nên kết quả lệch với `Math.round` của JS. Luôn tính bằng **số nguyên `3n/10`**.
- `doichieu.py` so số VT thật với **quota lý thuyết** (không còn mốc cứng "<30%", vì mốc 30% giờ
  chính là cái quota này). 03/11: 44/147 = 29,9% tại nhà · 48/160 = 30,0% toàn khu vực.

## VÁ APP PHẢI IDEMPOTENT
`patch_app.py` chạy trên `index.html` **tải từ repo** (tức bản ĐÃ vá lần trước). Mọi phép thay
chuỗi template đều phải: thấy bản cũ thì thay, thấy bản đã vá thì **bỏ qua** (hàm `rep` lo việc
này), tuyệt đối không `assert` cứng là "phải tìm thấy bản cũ". Riêng `TN_HANG_THANG` thì
**luôn ghi lại** theo `build_out.json` để tháng sau không bị kẹt số cũ.

⚠️ **BẪY: các bước vá CHỒNG LÊN NHAU.** Bước (3)(4)(5) vá câu/bảng, bước (6) vá lại NHÃN CHỮ
trong chính những câu đó. Nên "bản đã vá" mà bước (3)(4)(5) dò **không còn tồn tại** sau khi
bước (6) chạy → lần sau crash. Mỗi `rep()` bị chồng phải truyền **`dau_hieu` BẤT BIẾN**
(đoạn chữ mà bước 6 không đụng tới), đã làm cho 5 chỗ: bảng xếp hạng TN · "cần thêm điểm" ·
"so cả 2 vùng" · "kho hạng mấy" · "tổng khu vực". Thêm phép vá mới thì nhớ quy tắc này.
