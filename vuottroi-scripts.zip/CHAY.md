# BỘ SCRIPT VƯỢT TRỘI — BHSC CE Vùng Trung Bộ + Duyên Hải

Chạy trọn gói, chỉ cần **DATA.xlsx** (file Google Sheet "VTB - DH DATA 2026" xuất ra .xlsx):

```bash
bash chay.sh                        # ngày chốt = hôm nay
VT_NGAY_CHOT=31/10/2026 bash chay.sh
VT_THANG_CUOI=10 bash chay.sh       # ép tháng cuối (mặc định TỰ NHẬN từ tab 9)
```

Chạy xong có sẵn:
- `app/index.html` + `app/sw.js` → đẩy repo **vuot-troi**
- `index.html` + `vuottroi.json` + `VUOT-TROI-2026.xlsx` + `DATA-NGUON-VUOT-TROI.xlsx` → đẩy repo **bhsc-ce-vtb-vdh-dashboard**
- `VUOT TROI 2026 - <N> THANG DAU NAM BHSC.xlsx` → gửi anh Thu

## TỰ NHẬN, không ghi cứng
| Thứ | Cách nhận |
|---|---|
| Tháng cuối | tháng lớn nhất có đủ 12 kho ở tab `9.SỬA CHỮA KHÁCH LẺ` |
| Tháng chưa có lương | tab `3.THU NHẬP` có tới tháng nào, tháng sau đó trở đi dùng "có-bất-kỳ-data" |
| Bảng CHẤT LƯỢNG | tháng nào có ở `5. CHẤT LƯỢNG` thì lấy bảng đó, còn lại lấy `CHẤT LƯỢNG NEW` |
| Tên tab | khớp theo TIỀN TỐ (`1.GYKN`, `4.XỬ LÝ DD1 LẦN`...) nên thêm hậu tố vẫn chạy |

## HẰNG SỐ KHOÁ (chỉ đổi khi anh Thu chốt lại)
`build.py`: `QUOTA_MODE='round'` · `SCDV_4D_TU=7` · `CL2_TU=9` · `MIN_MONTHS=5`

## DỪNG LẠI VÀ HỎI ANH THU khi
1. `doichieu.py` báo **VƯỢT 30%**
2. Bất kỳ `audit*.py` báo lỗi, hoặc `test_app.js` có FAIL
3. Tab đổi tên/đổi số cột (các `assert` sẽ chặn) — xem bảng cột trong `build.py`
4. Có người **đang làm** mà MẤT Vượt Trội → nêu rõ nguyên nhân để anh duyệt
