#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CẬP NHẬT NGÀY trong app (chuỗi "cập nhật DD/MM/YYYY" bị ghi cứng trong template).
Phải chạy MỖI LẦN build, nếu không app hiện ngày của lần chạy trước.

    python3 set_ngay.py [index.html] [DD/MM/YYYY]
"""
import re, sys, os, datetime
HTML = sys.argv[1] if len(sys.argv) > 1 else 'index.html'
NGAY = sys.argv[2] if len(sys.argv) > 2 else datetime.datetime.now().strftime('%d/%m/%Y')
if not os.path.exists(HTML): sys.exit(f'THIẾU FILE: {HTML}')
h = open(HTML, encoding='utf-8').read()
cu = sorted(set(re.findall(r'cập nhật (\d{2}/\d{2}/\d{4})', h)))
h2, n = re.subn(r'(cập nhật )\d{2}/\d{2}/\d{4}', r'\g<1>' + NGAY, h)
assert n > 0, 'không tìm thấy chuỗi "cập nhật DD/MM/YYYY" — template đã đổi'

# Nhãn kỳ "Lũy kế 8 tháng đầu năm (T1–T8)" ghi CỨNG trong template -> sinh theo MONTHS
mths = re.findall(r'const MONTHS = \[([^\]]*)\]', h2)
assert mths, 'không đọc được const MONTHS trong app'
_last = max(int(x) for x in re.findall(r'T(\d+)', mths[0]))
_lbl = 'Lũy kế %d tháng đầu năm (T1–T%d)' % (_last, _last)
h2, nk = re.subn(r'Lũy kế \d+ tháng đầu năm \(T1–T\d+\)', _lbl, h2)
assert nk >= 2, f'nhãn kỳ: thay được {nk} chỗ (cần >=2) — template đã đổi'
print(f'Nhãn kỳ -> "{_lbl}"  ({nk} chỗ)')

# Nhãn "Giữ từ kỳ 6 tháng" ghi cứng trong template — sai nghĩa từ 22/09/2026
h2, k = re.subn(r'"Giữ từ kỳ 6 tháng"', '"Đã đạt kỳ 6 tháng"', h2)
if k: print(f'Nhãn "Giữ từ kỳ 6 tháng" -> "Đã đạt kỳ 6 tháng"  ({k} chỗ)')
open(HTML, 'w', encoding='utf-8').write(h2)
con = sorted(set(re.findall(r'cập nhật (\d{2}/\d{2}/\d{4})', h2)))
assert con == [NGAY], f'ghi hỏng, còn sót: {con}'
print(f"Ngày trong app: {', '.join(cu)} → {NGAY}  ({n} chỗ)")
