#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sinh các hằng dữ liệu JS mới cho index.html (app Vượt Trội) — T1..T8, phương án B."""
import json, re, openpyxl
from collections import defaultdict

D  = json.load(open('build_out.json', encoding='utf-8'))
NV, TN, TK, VD, KNraw, INC = D['NV'], D['TN'], D['TAIKHO'], D['VDATA'], D['KN'], D['INC']
MONTHS = ['T%d' % k for k in range(1, 11)]

CHOT  = set(D.get('CHOT6T', [])) & set(NV)
# 22/09/2026: 'bảo lưu 6 tháng' = GIỮ ĐIỂM T1–T6, KHÔNG giữ danh hiệu.
FINAL = {m for m, n in NV.items() if n['vt_round']}

j = lambda o: json.dumps(o, ensure_ascii=False, separators=(',', ':'))
def rnd(v, n=4): return None if v is None else round(v, n)

# ── NV (129) ──────────────────────────────────────────────────────
nv_out = []
for ma_, n in sorted(NV.items(), key=lambda x: (x[1]['vung'], x[1]['tinh'], x[1]['xepHang'])):
    thang = {}
    for m in MONTHS:
        mm = n['thang'].get(m)
        if not mm: continue
        tc = mm['tc']
        thang[m] = {'tc': {
            'khieuNai': {'kq': tc['khieuNai']['kq'], 'd': tc['khieuNai']['d']},
            'tiepCan': {'kpi': rnd(tc['tiepCan']['kpi']), 'kq': rnd(tc['tiepCan']['kq']), 'd': tc['tiepCan']['d']},
            'xldd': {'kq': tc['xldd']['kq'], 'd': tc['xldd']['d']}},
            'diem': mm['diem'], 'vt': False}
    nv_out.append({'ma': ma_, 'ten': n['ten'], 'chucVu': n['chucVu'], 'kho': n['kho'], 'tinh': n['tinh'],
                   'vung': n['vung'], 'diemLK': n['diemLK'], 'diem': n['diem'], 'xepHang': n['xepHang'],
                   'vuotTroi': ma_ in FINAL, 'soThang': n['soThangData'], 'duDK': n['duDieuKien'],
                   'chot6t': ma_ in CHOT, 'thang': thang})

# ── TN (13) — 6 tiêu chí ──────────────────────────────────────────
tn_out = []
for ma_, t in sorted(TN.items(), key=lambda x: (x[1]['vung'], x[1]['xepHang'])):
    thang = {}
    for m in MONTHS:
        mm = t['thang'].get(m)
        if not mm: continue
        thang[m] = {'tc': {k: {'kpi': rnd(v['kpi'], 6), 'kq': rnd(v['kq'], 6), 'd': v['d']}
                           for k, v in mm['tc'].items()}, 'tong': mm['tong'], 'hang': mm.get('hang')}
    tn_out.append({'ma': ma_, 'ten': t['ten'], 'chucVu': t['chucVu'], 'kho': t['kho'], 'tinh': t['tinh'],
                   'vung': t['vung'], 'diemLK': t['diemLK'], 'tongDiem': t['tongDiem'],
                   'xepHang': t['xepHang'], 'thang': thang})

# ── NV TẠI KHO (13) ───────────────────────────────────────────────
tk_out = [{'ma': m, 'ten': t['ten'], 'chucVu': t['chucVu'], 'kho': t['kho'], 'tinh': t['tinh'],
           'vung': t['vung'], 'hangThuNhap': t['hangThuNhap'], 'vuotTroi': t['vuotTroi']}
          for m, t in sorted(TK.items(), key=lambda x: (x[1]['kho'], x[1]['hangThuNhap']))]

# ── DET: [tiếp cận, số khiếu nại, số lỗi XLĐ] theo tháng ──────────
det = {}
for ma_, n in NV.items():
    d = {}
    for m in MONTHS:
        mm = n['thang'].get(m)
        if not mm: continue
        d[m] = [rnd(mm['tc']['tiepCan']['kq']), mm['tc']['khieuNai']['kq'], mm['tc']['xldd']['kq']]
    if d: det[ma_] = d

# ── KN: chi tiết khiếu nại theo mã ────────────────────────────────
kn = defaultdict(list)
for key, lst in KNraw.items():
    ma_, m = key.split('|')
    if ma_ not in NV: continue
    for x in lst:
        kn[ma_].append({'t': m, 'l': x['loai'] or '—', 'c': x['chude'],
                        'k': (re.search(r'(VTB|VDH)_[A-Z]{3}', x['kho']).group(0) if re.search(r'(VTB|VDH)_[A-Z]{3}', x['kho']) else ''),
                        'd': x['ngay'], 'nd': x['nd'][:190]})
for k in kn: kn[k].sort(key=lambda x: int(x['t'][1:]))

# ── VDATA (12 kho × 6 tiêu chí) + VTONG (trung bình 12 kho) ───────
CR6 = ['5sao', 'dungHen', 'tayNghe', 'xldd', 'tho5s', 'scdv', 'doi1', 'trondoi']
vdata = {k: {c: {m: [rnd(v[0], 6), rnd(v[1], 6), v[2]] for m, v in (VD[k].get(c) or {}).items()}
             for c in CR6 if VD[k].get(c)} for k in VD}
vtong = {}
for c in CR6:
    vtong[c] = {}
    for m in MONTHS:
        recs = [VD[k][c][m] for k in VD if VD[k].get(c, {}).get(m)]
        if not recs: continue
        kpis = [r[0] for r in recs if r[0] is not None]
        kqs = [r[1] for r in recs if r[1] is not None]
        if c == 'scdv':
            kpi, kq = (sum(kpis) if kpis else None), (sum(kqs) if kqs else None)
        else:
            kpi, kq = (kpis[0] if kpis else None), (sum(kqs) / len(kqs) if kqs else None)
        dat = 'Đạt' if (kq is not None and kpi is not None and kq >= kpi) else ('Đạt' if (kpi is None and all(r[2] == 'Đạt' for r in recs)) else 'Không đạt')
        vtong[c][m] = [rnd(kpi, 6), rnd(kq, 6), dat]

out = []
A = out.append
A('const MONTHS = %s;' % j(MONTHS))
A('// CHỐT anh Thu 28/08/2026: cộng đủ T1–T8 vào lũy kế (T8 data tới 27/08) → không còn tháng "tạm tính".')
A('const MPARTIAL = [];')
A('const isMPartial = (m)=>MPARTIAL.indexOf(m)>=0;')
A('const MONTHS_CUM = MONTHS.filter(m=>!isMPartial(m));')
# DMONTHS/VMONTHS trước ghi cứng 8 tháng trong template -> sinh theo MONTHS
A('const DMONTHS = %s;' % j(MONTHS))
A('const VMONTHS = %s;' % j(MONTHS))
A('const TN = %s;' % j(tn_out))
A('const NVKHO = %s;' % j(tk_out))
A('const DET = %s;' % j(det))
A('const KN = %s;' % j(dict(kn)))
A('const NV = %s;' % j(nv_out))
A('const VDATA = %s;' % j(vdata))
A('const VTONG = %s;' % j(vtong))
blob = '\n'.join(out)
open('app_data.js', 'w', encoding='utf-8').write(blob)

print("→ app_data.js  (%.0f KB)" % (len(blob)/1024))
print(f"   NV {len(nv_out)} (VT {sum(1 for x in nv_out if x['vuotTroi'])}, chốt6T {len(CHOT)}) | TN {len(tn_out)} | NVKHO {len(tk_out)}")
print(f"   DET {len(det)} NV | KN {sum(len(v) for v in kn.values())} phiếu / {len(kn)} NV | VDATA {len(vdata)} kho")
