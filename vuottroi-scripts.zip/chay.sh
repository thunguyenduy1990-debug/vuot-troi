#!/usr/bin/env bash
# CHẠY TRỌN GÓI VƯỢT TRỘI — cần duy nhất DATA.xlsx trong thư mục hiện tại.
#   bash chay.sh                      # ngày chốt = hôm nay
#   VT_NGAY_CHOT=31/10/2026 bash chay.sh
#   VT_THANG_CUOI=10 bash chay.sh     # ép tháng cuối (mặc định tự nhận từ tab 9)
set -euo pipefail
[ -f DATA.xlsx ] || { echo "THIẾU DATA.xlsx trong $(pwd)"; exit 1; }

echo "══ 1. CHẤM ĐIỂM ════════════════════════════════════════"
python3 build.py

echo; echo "══ 2. SOÁT ĐỘC LẬP (phải KHÔNG CÓ LỖI) ═════════════════"
python3 audit.py && python3 audit2.py && python3 audit3.py

echo; echo "══ 3. XUẤT FILE EXCEL + vuottroi.json ══════════════════"
python3 export_excel.py
python3 gen_vuottroi_json.py

echo; echo "══ 4. APP VƯỢT TRỘI ════════════════════════════════════"
mkdir -p app
curl -sSL -o app/index.html https://raw.githubusercontent.com/thunguyenduy1990-debug/vuot-troi/main/index.html
curl -sSL -o app/sw.js     https://raw.githubusercontent.com/thunguyenduy1990-debug/vuot-troi/main/sw.js
python3 gen_app.py
cp app_data.js build_out.json numparse.py patch_app.py set_ngay.py test_app.js app/
( cd app && python3 patch_app.py && python3 set_ngay.py index.html "${VT_NGAY_CHOT:-$(date +%d/%m/%Y)}" && node test_app.js | tail -1 )

echo; echo "══ 5. TAB 10 CỦA WEB KẾT QUẢ VẬN HÀNH ══════════════════"
curl -sSL -o index.html https://raw.githubusercontent.com/thunguyenduy1990-debug/bhsc-ce-vtb-vdh-dashboard/main/index.html
python3 add_tab10.py
python3 embed_vt.py
cp "$(ls -t 'VUOT TROI 2026 - '*.xlsx | head -1)" VUOT-TROI-2026.xlsx
cp DATA.xlsx DATA-NGUON-VUOT-TROI.xlsx

echo; echo "══ 6. ĐỐI CHIẾU APP ↔ WEB ↔ EXCEL ══════════════════════"
python3 doichieu.py

echo; echo "XONG. Đẩy lên 2 repo:"
echo "   vuot-troi                  <-  app/index.html  app/sw.js"
echo "   bhsc-ce-vtb-vdh-dashboard  <-  index.html  vuottroi.json  VUOT-TROI-2026.xlsx  DATA-NGUON-VUOT-TROI.xlsx"
