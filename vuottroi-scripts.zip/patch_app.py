#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NHÚNG DỮ LIỆU MỚI VÀO index.html
Chỉ THAY các hằng dữ liệu — không đụng vào giao diện / công thức của app.
Chạy sau gen_app.py:   python3 patch_app.py
"""
import re, sys, os

HTML = 'index.html'
DATA = 'app_data.js'
CONSTS = ['MONTHS', 'MPARTIAL', 'MONTHS_CUM', 'DMONTHS', 'VMONTHS',
          'TN', 'NVKHO', 'DET', 'KN', 'NV', 'VDATA', 'VTONG']

for f in (HTML, DATA):
    if not os.path.exists(f): sys.exit(f'THIẾU FILE: {f}')

html = open(HTML, encoding='utf-8').read()
new  = open(DATA, encoding='utf-8').read()
n0 = len(html)
done, miss = [], []

for name in CONSTS:
    m = re.search(r'^const %s = .*?;$' % re.escape(name), new, re.M | re.S)
    if not m: miss.append(f'app_data.js thiếu {name}'); continue
    pat = re.compile(r'const %s = (\[.*?\]|\{.*?\}|[^;\n]*);' % re.escape(name), re.S)
    mm = pat.search(html)
    if not mm:
        # hằng chưa có trong app -> chèn ngay sau NV
        anchor = re.search(r'const NV = \[.*?\];', html, re.S)
        if not anchor: miss.append(f'index.html không có chỗ chèn {name}'); continue
        html = html[:anchor.end()] + '\n' + m.group(0) + html[anchor.end():]
        done.append(name + ' (chèn mới)')
    else:
        html = html[:mm.start()] + m.group(0) + html[mm.end():]
        done.append(name)

if miss:
    print('⚠️  CẢNH BÁO:'); [print('   -', x) for x in miss]

open(HTML, 'w', encoding='utf-8').write(html)
print('Đã thay:', ', '.join(done))
print(f'{HTML}: {n0/1024:.0f}KB → {len(html)/1024:.0f}KB')

# tăng CACHE trong sw.js
if os.path.exists('sw.js'):
    sw = open('sw.js', encoding='utf-8').read()
    m = re.search(r'CACHE="vuottroi-v(\d+)"', sw)
    if m:
        v = int(m.group(1)) + 1
        sw = sw.replace(m.group(0), 'CACHE="vuottroi-v%d"' % v)
        open('sw.js', 'w', encoding='utf-8').write(sw)
        print(f'sw.js: CACHE → vuottroi-v{v}')
print('\n→ Bước tiếp: node test_app.js  (phải PASS HẾT trước khi deploy)')

# ── 25/10/2026: thêm 2 tiêu chí Trưởng nhóm (CL 1 Đổi 1 · CL BH Trọn Đời) ──
# Hai hằng này ghi CỨNG trong template, không sinh từ gen_app.py -> phải vá ở đây.
import io
html = open(HTML, encoding='utf-8').read()
CT_OLD = ('const CRIT_TN = { "5sao":"Phục vụ 5 Sao", dungHen:"Đúng hẹn", '
          'tayNghe:"Tay nghề chuẩn (IMEI lặp lại)", xldd:"Xử lý DĐ 1 lần", '
          'tho5s:"Thợ Chuẩn 5S", scdv:"Sửa chữa khách lẻ" }')
CT_NEW = ('const CRIT_TN = { "5sao":"Phục vụ 5 Sao", dungHen:"Đúng hẹn", '
          'tayNghe:"Tay nghề chuẩn (IMEI lặp lại)", xldd:"Xử lý DĐ 1 lần", '
          'tho5s:"Thợ Chuẩn 5S", scdv:"Sửa chữa khách lẻ", '
          'doi1:"CL 1 Đổi 1", trondoi:"CL BH Trọn Đời" }')
VC_OLD = '["tho5s","🧰 Thợ Chuẩn 5S",2],["scdv","💰 Sửa chữa khách lẻ",2]]'
VC_NEW = ('["tho5s","🧰 Thợ Chuẩn 5S",2],["scdv","💰 Sửa chữa khách lẻ",2],'
          '["doi1","🔁 CL 1 Đổi 1",2],["trondoi","🛡️ CL BH Trọn Đời",2]]')
add = []
if CT_OLD in html: html = html.replace(CT_OLD, CT_NEW); add.append('CRIT_TN')
if VC_OLD in html: html = html.replace(VC_OLD, VC_NEW); add.append('V_CRITS')
assert 'doi1:"CL 1 Đổi 1"' in html and '["doi1"' in html, \
       'KHÔNG vá được 2 tiêu chí mới vào template — chuỗi đã đổi, phải sửa patch_app.py'
open(HTML, 'w', encoding='utf-8').write(html)
print('Đã thêm 2 tiêu chí mới vào:', ', '.join(add) or '(đã có sẵn)')
