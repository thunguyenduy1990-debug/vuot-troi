#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NHÚNG DỮ LIỆU MỚI VÀO index.html
Chỉ THAY các hằng dữ liệu — không đụng vào giao diện / công thức của app.
Chạy sau gen_app.py:   python3 patch_app.py
"""
import re, sys, os

HTML = 'index.html'
DATA = 'app_data.js'
CONSTS = ['MONTHS', 'MPARTIAL', 'MONTHS_CUM', 'DMONTHS', 'VMONTHS',
          'TN', 'NVKHO', 'DET', 'KN', 'NV', 'VDATA', 'VTONG']

for f in (HTML, DATA):
    if not os.path.exists(f): sys.exit(f'THIẾU FILE: {f}')

html = open(HTML, encoding='utf-8').read()
new  = open(DATA, encoding='utf-8').read()
n0 = len(html)
done, miss = [], []

for name in CONSTS:
    m = re.search(r'^const %s = .*?;$' % re.escape(name), new, re.M | re.S)
    if not m: miss.append(f'app_data.js thiếu {name}'); continue
    pat = re.compile(r'const %s = (\[.*?\]|\{.*?\}|[^;\n]*);' % re.escape(name), re.S)
    mm = pat.search(html)
    if not mm:
        # hằng chưa có trong app -> chèn ngay sau NV
        anchor = re.search(r'const NV = \[.*?\];', html, re.S)
        if not anchor: miss.append(f'index.html không có chỗ chèn {name}'); continue
        html = html[:anchor.end()] + '\n' + m.group(0) + html[anchor.end():]
        done.append(name + ' (chèn mới)')
    else:
        html = html[:mm.start()] + m.group(0) + html[mm.end():]
        done.append(name)

if miss:
    print('⚠️  CẢNH BÁO:'); [print('   -', x) for x in miss]

open(HTML, 'w', encoding='utf-8').write(html)
print('Đã thay:', ', '.join(done))
print(f'{HTML}: {n0/1024:.0f}KB → {len(html)/1024:.0f}KB')

# tăng CACHE trong sw.js
if os.path.exists('sw.js'):
    sw = open('sw.js', encoding='utf-8').read()
    m = re.search(r'CACHE="vuottroi-v(\d+)"', sw)
    if m:
        v = int(m.group(1)) + 1
        sw = sw.replace(m.group(0), 'CACHE="vuottroi-v%d"' % v)
        open('sw.js', 'w', encoding='utf-8').write(sw)
        print(f'sw.js: CACHE → vuottroi-v{v}')
print('\n→ Bước tiếp: node test_app.js  (phải PASS HẾT trước khi deploy)')

# ── 25/10/2026: thêm 2 tiêu chí Trưởng nhóm (CL 1 Đổi 1 · CL BH Trọn Đời) ──
# Hai hằng này ghi CỨNG trong template, không sinh từ gen_app.py -> phải vá ở đây.
import io
html = open(HTML, encoding='utf-8').read()
CT_OLD = ('const CRIT_TN = { "5sao":"Phục vụ 5 Sao", dungHen:"Đúng hẹn", '
          'tayNghe:"Tay nghề chuẩn (IMEI lặp lại)", xldd:"Xử lý DĐ 1 lần", '
          'tho5s:"Thợ Chuẩn 5S", scdv:"Sửa chữa khách lẻ" }')
CT_NEW = ('const CRIT_TN = { "5sao":"Phục vụ 5 Sao", dungHen:"Đúng hẹn", '
          'tayNghe:"Tay nghề chuẩn (IMEI lặp lại)", xldd:"Xử lý DĐ 1 lần", '
          'tho5s:"Thợ Chuẩn 5S", scdv:"Sửa chữa khách lẻ", '
          'doi1:"CL 1 Đổi 1", trondoi:"CL BH Trọn Đời" }')
VC_OLD = '["tho5s","🧰 Thợ Chuẩn 5S",2],["scdv","💰 Sửa chữa khách lẻ",2]]'
VC_NEW = ('["tho5s","🧰 Thợ Chuẩn 5S",2],["scdv","💰 Sửa chữa khách lẻ",2],'
          '["doi1","🔁 CL 1 Đổi 1",2],["trondoi","🛡️ CL BH Trọn Đời",2]]')
add = []
if CT_OLD in html: html = html.replace(CT_OLD, CT_NEW); add.append('CRIT_TN')
if VC_OLD in html: html = html.replace(VC_OLD, VC_NEW); add.append('V_CRITS')
assert 'doi1:"CL 1 Đổi 1"' in html and '["doi1"' in html, \
       'KHÔNG vá được 2 tiêu chí mới vào template — chuỗi đã đổi, phải sửa patch_app.py'
open(HTML, 'w', encoding='utf-8').write(html)
print('Đã thêm 2 tiêu chí mới vào:', ', '.join(add) or '(đã có sẵn)')


# ── 01/11/2026: MỖI KHO CÓ NHIỀU TN (QLDV + Trưởng Ca) — VÁ IDEMPOTENT ──────
#   • Trưởng Ca chỉ chấm từ T10 -> không được dùng làm "TN đại diện kho".
#   • Xếp hạng chung bảng theo ĐIỂM THÁNG CUỐI (anh Thu chốt 01/11).
#   Chạy lại trên index.html ĐÃ vá (lấy từ repo) thì tự bỏ qua, chỉ cập nhật TN_HANG_THANG.
html = open(HTML, encoding='utf-8').read()
import json as _json
_D = _json.load(open('build_out.json', encoding='utf-8'))
_HT = _D['meta']['tnHangThang']
P, SKIP = [], []
def rep(old, new, ten, dau_hieu=None):
    """Thay old->new. Nếu đã vá rồi (nhận ra qua dau_hieu/new) thì bỏ qua."""
    global html
    if html.count(old) == 1:
        html = html.replace(old, new); P.append(ten); return
    moc = dau_hieu if dau_hieu is not None else new
    assert moc in html, f'vá {ten}: không thấy bản cũ ({html.count(old)} chỗ) lẫn bản đã vá — template đã đổi'
    SKIP.append(ten)

# (1) Helper: TN đại diện kho = người có kỳ chấm dài nhất (tuThang nhỏ nhất)
if 'const tnOfKho' not in html:
    HELP = ('\n// 01/11/2026: nhiều TN/kho -> lấy người chấm đủ kỳ làm đại diện kho; xếp hạng theo điểm T%d.\n'
            'const TN_HANG_THANG=%d;\n'
            'const TN_REP={}; TN.forEach(t=>{const k=t.kho; if(!TN_REP[k]||(t.tuThang||1)<(TN_REP[k].tuThang||1)) TN_REP[k]=t;});\n'
            'const tnOfKho=(k)=>{const m=String(k||"").match(/(VTB|VDH)_[A-Z]{3}/); return m?TN_REP[m[0]]:undefined;};\n'
            'const tnOfTinh=(x)=>TN.filter(t=>t.tinh===x).sort((a,b)=>(a.tuThang||1)-(b.tuThang||1))[0];\n'
            'const tnDiemXH=(t)=>!t?0:(t.diemXH!=null?t.diemXH:t.tongDiem);\n'
            'const tnCV=(t)=>!t?"":(t.chucVu==="Trưởng Ca"?("Trưởng ca · từ T"+(t.tuThang||1)):"QLDV");\n') % (_HT, _HT)
    m = re.search(r'const NVKHO = \[.*?\];', html, re.S)
    assert m, 'không tìm thấy const NVKHO để chèn helper'
    html = html[:m.end()] + HELP + html[m.end():]
    P.append('helper tnOfKho/tnOfTinh')
else:
    SKIP.append('helper (đã có)')
# tháng xếp hạng phải LUÔN khớp build_out.json, kể cả khi helper đã có sẵn
html, nh = re.subn(r'const TN_HANG_THANG=\d+;', 'const TN_HANG_THANG=%d;' % _HT, html)
assert nh == 1, f'TN_HANG_THANG: {nh} chỗ (cần 1)'
P.append(f'TN_HANG_THANG={_HT}')

# (1b) CƠ SỞ XẾP HẠNG — anh Thu chốt 02/11: tnDiemXH() = ĐIỂM DÙNG XẾP HẠNG (lũy kế),
#      tnDiemThang() = điểm tháng cuối (tham khảo). Định nghĩa 1 chỗ nên mọi câu/bảng
#      dùng tnDiemXH() tự ra đúng số, chỉ còn phải sửa NHÃN chữ.
_THEO = _D['meta'].get('tnHangTheo', 'luyke')
_XH = ('const tnDiemXH=(t)=>!t?0:(t.diemHang!=null?t.diemHang:t.tongDiem);'
       '   // 02/11: điểm XẾP HẠNG = %s\n'
       'const tnDiemThang=(t)=>!t?0:(t.diemXH!=null?t.diemXH:0);'
       '   // điểm tháng cuối, chỉ tham khảo\n') % ('LŨY KẾ' if _THEO == 'luyke' else 'điểm tháng cuối')
html, nx = re.subn(r'const tnDiemXH=[^\n]*\n(const tnDiemThang=[^\n]*\n)?', _XH, html, count=1)
assert nx == 1, f'tnDiemXH: {nx} chỗ (cần 1)'
assert 'const tnDiemThang=' in html, 'thiếu tnDiemThang sau khi vá'
P.append(f'cơ sở xếp hạng = {_THEO}')

# (2) Mọi chỗ "TN của kho/tỉnh" -> helper (KHÔNG đụng tra cứu theo mã/tên)
n1 = len(re.findall(r'TN\.find\(x=>x\.tinh===([A-Za-z0-9_\[\]\.]+)\)', html))
n2 = len(re.findall(r'TN\.find\(x=>x\.kho===([A-Za-z0-9_\[\]\.]+)\)', html))
if n1 or n2:
    html = re.sub(r'TN\.find\(x=>x\.tinh===([A-Za-z0-9_\[\]\.]+)\)', r'tnOfTinh(\1)', html)
    html = re.sub(r'TN\.find\(x=>x\.kho===([A-Za-z0-9_\[\]\.]+)\)',  r'tnOfKho(\1)', html)
    P.append(f'{n1} chỗ theo tỉnh + {n2} chỗ theo kho')
else:
    SKIP.append('TN.find theo kho/tỉnh (đã thay)')
assert len(re.findall(r'tnOfTinh\(', html)) >= 5 and len(re.findall(r'tnOfKho\(', html)) >= 3, \
    'thiếu tnOfTinh/tnOfKho sau khi vá — template đã đổi'

# (3) Bảng xếp hạng TN: điểm hiển thị = điểm tháng cuối, kèm lũy kế + chức vụ
rep('<span class="nm">${esc(t.ten)} <small>· ${esc(t.tinh)}</small></span><span class="pt">${t.tongDiem}</span>',
    '<span class="nm">${esc(t.ten)} <small>· ${esc(t.tinh)} · ${esc(tnCV(t))}</small></span>'
    '<span class="pt">${tnDiemXH(t)}<small style="display:block;font-size:10px;font-weight:400;opacity:.7">LK ${t.tongDiem}</small></span>',
    'bảng xếp hạng TN', '${esc(tnCV(t))}</small></span>')

# (4) Chat TN: khoảng cách & điểm so hạng đều theo điểm tháng cuối
rep('const gap = top.ma!==d.ma? top.tongDiem-d.tongDiem: 0;',
    'const gap = top.ma!==d.ma? tnDiemXH(top)-tnDiemXH(d): 0;', 'gap theo điểm T cuối')
rep('`Dạ, anh/chị cần thêm ${gap}đ để bắt kịp ${top.ten} (${top.tongDiem}đ) — hạng 1 ${d.vung}.',
    '`Dạ, anh/chị cần thêm ${gap}đ (so điểm Tháng ${TN_HANG_THANG}) để bắt kịp ${top.ten} (${tnDiemXH(top)}đ) — hạng 1 ${d.vung}.',
    'câu "cần thêm điểm"', 'cần thêm ${gap}đ (so điểm')
rep('const r = rankOf(d.tongDiem, TN.map(t=>t.tongDiem));\n        const bestAll = [...TN].sort((a,b)=>b.tongDiem-a.tongDiem)[0];',
    'const r = rankOf(tnDiemXH(d), TN.map(t=>tnDiemXH(t)));\n        const bestAll = [...TN].sort((a,b)=>tnDiemXH(b)-tnDiemXH(a))[0];',
    'so sánh 2 vùng')
rep('return `Dạ, so cả 13 trưởng nhóm 2 vùng: anh/chị hạng ${r}/13 với ${d.tongDiem}đ. Dẫn đầu chung: ${bestAll.ten} (${bestAll.tinh}, ${bestAll.tongDiem}đ).',
    'return `Dạ, so cả ${TN.length} trưởng nhóm/trưởng ca 2 vùng: anh/chị hạng ${r}/${TN.length} với ${tnDiemXH(d)}đ (điểm Tháng ${TN_HANG_THANG}). Dẫn đầu chung: ${bestAll.ten} (${bestAll.tinh}, ${tnDiemXH(bestAll)}đ).',
    'câu "so cả 2 vùng"', 'so cả ${TN.length} trưởng nhóm/trưởng ca 2 vùng')
rep('return `Dạ, kho ${d.tinh} đang hạng ${d.xepHang}/${sameVung.length} ${d.vung==="VTB"?"Vùng Trung Bộ":"Vùng Duyên Hải"} với ${d.tongDiem}đ ${medal(d.xepHang)??""}.\\n${gap>0? `Đứng đầu: ${top.ten} (${top.tongDiem}đ) — cách ${gap}đ.`',
    'return `Dạ, anh/chị đang hạng ${d.xepHang}/${sameVung.length} ${d.vung==="VTB"?"Vùng Trung Bộ":"Vùng Duyên Hải"} với ${tnDiemXH(d)}đ điểm Tháng ${TN_HANG_THANG} (lũy kế ${d.tongDiem}đ) ${medal(d.xepHang)??""}.\\n${gap>0? `Đứng đầu: ${top.ten} (${tnDiemXH(top)}đ) — cách ${gap}đ.`',
    'câu "kho hạng mấy"', 'anh/chị đang hạng ${d.xepHang}/${sameVung.length}')

# (5) Bỏ các con số ghi cứng 13
rep('"Kho tôi hạng mấy trong vùng / so với cả 13 TN?"',
    '`Kho tôi hạng mấy trong vùng / so với cả ${TN.length} TN?`', 'gợi ý câu hỏi')
rep('• 13 trưởng nhóm, dẫn đầu: ${topTN.ten} (${topTN.tinh}, ${topTN.tongDiem}đ) 🥇',
    '• ${TN.length} trưởng nhóm/trưởng ca, dẫn đầu: ${topTN.ten} (${topTN.tinh}, ${tnDiemXH(topTN)}đ T${TN_HANG_THANG}) 🥇',
    'câu tổng khu vực', '${TN.length} trưởng nhóm/trưởng ca, dẫn đầu')

# (6) NHÃN CHỮ theo cơ sở xếp hạng mới (lũy kế). Nhận cả bản cũ "điểm Tháng N".
rep('<small style="display:block;font-size:10px;font-weight:400;opacity:.7">LK ${t.tongDiem}</small>',
    '<small style="display:block;font-size:10px;font-weight:400;opacity:.7">T${TN_HANG_THANG} ${tnDiemThang(t)}</small>',
    'nhãn nhỏ bảng xếp hạng')
rep('cần thêm ${gap}đ (so điểm Tháng ${TN_HANG_THANG}) để bắt kịp',
    'cần thêm ${gap}đ (so điểm lũy kế) để bắt kịp', 'nhãn "cần thêm điểm"')
rep('hạng ${r}/${TN.length} với ${tnDiemXH(d)}đ (điểm Tháng ${TN_HANG_THANG}).',
    'hạng ${r}/${TN.length} với ${tnDiemXH(d)}đ lũy kế.', 'nhãn "so cả 2 vùng"')
rep('với ${tnDiemXH(d)}đ điểm Tháng ${TN_HANG_THANG} (lũy kế ${d.tongDiem}đ) ${medal(d.xepHang)??""}',
    'với ${tnDiemXH(d)}đ lũy kế (điểm Tháng ${TN_HANG_THANG}: ${tnDiemThang(d)}đ) ${medal(d.xepHang)??""}',
    'nhãn "kho hạng mấy"')
rep('(${topTN.tinh}, ${tnDiemXH(topTN)}đ T${TN_HANG_THANG}) 🥇',
    '(${topTN.tinh}, ${tnDiemXH(topTN)}đ lũy kế) 🥇', 'nhãn "tổng khu vực"')

open(HTML, 'w', encoding='utf-8').write(html)
assert 'TN.find(x=>x.tinh' not in html and 'TN.find(x=>x.kho' not in html, 'còn sót TN.find theo kho/tỉnh'
print('Vá nhiều-TN-mỗi-kho — mới:', ' · '.join(P) or '(không)')
if SKIP: print('   đã có sẵn:', ' · '.join(SKIP))
