#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ĐỐI CHIẾU 3 NGUỒN: app/index.html ↔ vuottroi.json ↔ file Excel. Phải KHỚP TUYỆT ĐỐI."""
import json, re, openpyxl, sys
BO = json.load(open('build_out.json', encoding='utf-8'))
VT = json.load(open('vuottroi.json', encoding='utf-8'))
h = open('app/index.html', encoding='utf-8').read()
def c(n): return json.loads(re.search(r'const %s = (\[.*?\]|\{.*?\});' % n, h, re.S).group(1))
NV_APP, TN_APP, KHO_APP = c('NV'), c('TN'), c('NVKHO')
F = {m for m, n in BO['NV'].items() if n['vt_round']}
TKVT = {m for m, t in BO['TAIKHO'].items() if t['vuotTroi']}
err = []
if {n['ma'] for n in NV_APP if n.get('vuotTroi')} != F: err.append('APP vs BUILD lệch VT')
web = {p['ma']: p for p in VT['nguoi']}
if {m for m, p in web.items() if p['nhom'] == 'nha' and p['vt']} != F: err.append('WEB nhà')
if {m for m, p in web.items() if p['nhom'] == 'kho' and p['vt']} != TKVT: err.append('WEB kho')
for n in NV_APP:
    w = web.get(n['ma'])
    if not w: err.append(f"WEB thiếu {n['ma']}"); continue
    if bool(n.get('vuotTroi')) != bool(w['vt']) or n['diem'] != w['diem'] or n['xepHang'] != w['hang']:
        err.append(f"NV {n['ma']} lệch")
tnw = {t['ma']: t for t in VT['tn']}
for t in TN_APP:
    w = tnw.get(t['ma'])
    if not w or t['tongDiem'] != w['tong'] or t['xepHang'] != w['hang']: err.append(f"TN {t['ma']} lệch")
    elif json.dumps(t['diemLK'], sort_keys=True) != json.dumps(w['diemLK'], sort_keys=True):
        err.append(f"TN {t['ma']} diemLK lệch")
ws = openpyxl.load_workbook('VUOT-TROI-2026.xlsx', data_only=True)['VƯỢT TRỘI NV.']
MARK = {'X', 'ĐẠT', 'CÓ', '1', 'VƯỢT TRỘI'}
nha, kho, cur, tot = set(), set(), None, 0
for r in range(6, ws.max_row + 1):
    b = str(ws.cell(r, 2).value or '')
    if b.startswith('■'): cur = 'kho' if 'TẠI KHO' in b.upper() else 'nha'; continue
    m = str(ws.cell(r, 5).value or '').strip()
    if not re.fullmatch(r'\d{3,7}', m): continue
    tot += 1
    if str(ws.cell(r, 15).value or '').strip().upper() in MARK: (kho if cur == 'kho' else nha).add(m)
if nha != F: err.append('EXCEL nhà lệch')
if kho != TKVT: err.append('EXCEL kho lệch')
n = len(BO['NV']) + len(BO['TAIKHO'])
tl = (len(F) + len(TKVT)) / n
# chốt 03/11: quota mỗi kho = min(round(30% × TỔNG NHÂN SỰ kho), số người đủ ĐK).
# Tổng có thể nhích trên 30% do làm tròn lên -> so với QUOTA LÝ THUYẾT, không so mốc cứng 30%.
from collections import defaultdict as _dd
_byk = _dd(list)
for _m, _x in BO['NV'].items(): _byk[_x['kho']].append(_x)
_q30 = lambda n: (3 * n) // 10 + (1 if (3 * n) % 10 >= 6 else 0)   # >=0,6 lên · <=0,5 xuống
_quota = sum(min(_q30(len(v)), sum(1 for y in v if y['duDieuKien'])) for v in _byk.values())
if len(F) != _quota: err.append(f'VT tại nhà {len(F)} != tổng quota 12 kho {_quota}')
print(f"QUOTA tại nhà: {len(F)}/{len(BO['NV'])} = {len(F)/len(BO['NV'])*100:.1f}% "
      f"(30% TỔNG NHÂN SỰ kho · >=0,6 lên / <=0,5 xuống → quota lý thuyết {_quota})")
print(f"APP {len(NV_APP)}NV/{len(F)}VT · WEB {len(web)}/{VT['meta']['vtNha']}+{VT['meta']['vtKho']} "
      f"· EXCEL {tot}/{len(nha)}+{len(kho)} · TN {len(TN_APP)} · tại kho {len(KHO_APP)}")
print(f"TỔNG VƯỢT TRỘI: {len(F)+len(TKVT)}/{n} = {tl*100:.1f}%  →  "
      + ("KHỚP QUOTA OK" if tl <= 0.32 else "!!! VƯỢT XA 30% — SAI MẪU SỐ, PHẢI HỎI ANH THU"))
if err:
    print("KẾT LUẬN: LỆCH\n  - " + "\n  - ".join(err[:10])); sys.exit(1)
print("KẾT LUẬN: 3 NGUỒN KHỚP TUYỆT ĐỐI")
