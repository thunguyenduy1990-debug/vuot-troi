#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BUILD DATA VƯỢT TRỘI 2026 — T1..T8  (chốt anh Thu 28/08/2026)
Nguồn: VTB_DH_DATA_2026.xlsx (tải từ Google Sheet) + Danh Sách Nhân Sự Bảo Hành.xlsx
Xuất : build_out.json
"""
import openpyxl, re, json, math, datetime, os

# Ngày ghi lên app/web. Mặc định = hôm nay; đổi bằng  VT_NGAY_CHOT=31/10/2026 python3 build.py
NGAY_CHOT = os.environ.get('VT_NGAY_CHOT') or datetime.datetime.now().strftime('%d/%m/%Y')
from collections import defaultdict, Counter

XLSX_GS  = 'DATA.xlsx'          # file tải từ Google Sheet "VTB - DH DATA 2026"

# ── PHẠM VI THÁNG: TỰ NHẬN từ dữ liệu, không ghi cứng ─────────────────────────
# Tháng mới nhất = tháng lớn nhất mà tab SCDV (9) có đủ số liệu kho.
# Nhờ vậy tháng sau anh Thu gửi T11/T12 là chạy được ngay, không phải sửa code.
def _thang_moi_nhat(path):
    import openpyxl as _o, re as _re
    wb0 = _o.load_workbook(path, data_only=True, read_only=True)
    nm = [n for n in wb0.sheetnames if n.strip().startswith('9.SỬA CHỮA')]
    assert nm, 'không thấy tab 9.SỬA CHỮA KHÁCH LẺ'
    ws0, best = wb0[nm[0]], 1
    for row in ws0.iter_rows(min_row=4, values_only=True):
        m, kho = row[0], row[2] if len(row) > 2 else None
        if isinstance(m, (int, float)) and 1 <= m <= 12 and _re.search(r'(VTB|VDH)_[A-Z]{3}', str(kho or '')):
            best = max(best, int(m))
    wb0.close()
    return best

THANG_CUOI = int(os.environ.get('VT_THANG_CUOI') or _thang_moi_nhat(XLSX_GS))
MONTHS   = list(range(1, THANG_CUOI + 1))
CUM      = list(range(1, THANG_CUOI + 1))
MIN_MONTHS = 5                        # tối thiểu 5 tháng CÓ DATA
# MIN_NOPAY: từ tháng này CHƯA có bảng lương -> "tháng có đi làm" căn cứ có-bất-kỳ-data.
# Tự nhận = (tháng lương lớn nhất trong tab 3.THU NHẬP) + 1.
def _thang_luong_cuoi(path):
    import openpyxl as _o
    wb0 = _o.load_workbook(path, data_only=True, read_only=True)
    nm = [n for n in wb0.sheetnames if n.strip().startswith('3.THU NHẬP')]
    ws0, best = wb0[nm[0]], 0
    for row in ws0.iter_rows(min_row=2, values_only=True):
        m = row[0]
        if isinstance(m, (int, float)) and 1 <= m <= 12: best = max(best, int(m))
    wb0.close()
    return best

MIN_NOPAY  = _thang_luong_cuoi(XLSX_GS) + 1
SCDV_4D_TU = 7                        # SCDV: 2đ T1..T6, 4đ từ T7
CL2_TU     = 9                        # 1 Đổi 1 & BH Trọn Đời: xét TỪ T9 (chốt anh Thu 25/10)
QUOTA_MODE = 'round'                  # quota lũy kế: làm tròn gần nhất
# anh Thu chốt 02/11: QLDV & Trưởng ca phòng ban BẢO HÀNH TẠI KHO -> KHÔNG tính Vượt Trội,
# bỏ hẳn khỏi app/web (không vào bảng Trưởng nhóm, cũng không vào nhóm nhân viên tại kho).
BO_QLDV  = {'153917', '170083', '3177', '39675', '66577'}
TN_TAIKHO = set()                     # không còn ai phòng ban Tại Kho được xét
TRUONGCA_TU = 10                      # Trưởng Ca chỉ đánh giá TỪ T10 (chốt 01/11)
LOC_TAINHA = {'79986'}                # Lê Đức Lộc: phòng ban Tại Kho -> anh Thu chốt xếp TẠI NHÀ

def ma(v):
    if v is None: return None
    if isinstance(v, float) and v == int(v): return str(int(v))
    return str(v).strip()

from numparse import num as _num
def num(v, kind='auto'): return _num(v, kind)

def to_date(v):
    """Ngày trong Sheet có thể là datetime, số serial Excel, hoặc chuỗi."""
    if v is None: return ''
    if isinstance(v, datetime.datetime): return v.strftime('%d/%m/%Y')
    if isinstance(v, datetime.date): return v.strftime('%d/%m/%Y')
    if isinstance(v, (int, float)) and 20000 < v < 80000:      # serial Excel
        return (datetime.datetime(1899, 12, 30) + datetime.timedelta(days=int(v))).strftime('%d/%m/%Y')
    s = str(v).strip()
    m = re.fullmatch(r'(\d{1,2})[/-](\d{1,2})[/-](\d{4})', s)
    if m: return '%02d/%02d/%s' % (int(m.group(1)), int(m.group(2)), m.group(3))
    try:
        f = float(s)
        if 20000 < f < 80000:
            return (datetime.datetime(1899, 12, 30) + datetime.timedelta(days=int(f))).strftime('%d/%m/%Y')
    except ValueError: pass
    return s

def _tab(wb, dau):
    """Khớp tên tab theo TIỀN TỐ — anh Thu hay thêm hậu tố (vd '1.GYKN - NV TAY NGHỀ 1063')."""
    hit = [n for n in wb.sheetnames if n.strip().startswith(dau)]
    assert len(hit) == 1, f'tab bắt đầu bằng {dau!r}: tìm thấy {hit} (cần đúng 1)'
    return hit[0]

def khocode(s):
    m = re.search(r'(VTB|VDH)_[A-Z]{3}', str(s or ''))
    return m.group(0) if m else None

# ══════════════════════════════════════════════════════════════════
# 1. ROSTER
# ══════════════════════════════════════════════════════════════════
w = openpyxl.load_workbook(XLSX_GS, data_only=True)['DANH SÁCH NHÂN SỰ']
H = [w.cell(row=1, column=c).value for c in range(1, 15)]
ROS = {}
for r in range(2, w.max_row + 1):
    if not w.cell(row=r, column=1).value: continue
    d = dict(zip(H, [w.cell(row=r, column=c).value for c in range(1, 15)]))
    d = {str(k).strip(): v for k, v in d.items()}      # tiêu đề Sheet không có dấu cách thừa
    ROS[ma(d['Mã Nhân Viên'])] = d

TAIKHO_ST = {'VDH_KHH - Kho BHSC CE Khánh Hòa': 'VDH_KHH_TK',
             'VTB_DNA - Kho BHSC CE Đà Nẵng':   'VTB_DNA_TK'}

def kho_of(m):
    st = str(ROS[m]['Tên Siêu Thị'])
    for k, v in TAIKHO_ST.items():
        if st.startswith(k): return v
    return khocode(st)

def kho_tn(m):
    """Trưởng nhóm / Trưởng ca: tab 5·7·8·9 KHÔNG có dòng riêng cho kho 'Tại Kho'
    (chỉ 12 kho) nên 4 người Tại Kho chấm theo KPI của KHO MẸ."""
    k = kho_of(m)
    return k[:-3] if (k and k.endswith('_TK')) else k

TEN_KHO = {'VTB_HTI':'Hà Tĩnh','VTB_QBI':'Quảng Bình','VTB_QTR':'Quảng Trị','VTB_HUE':'Huế',
           'VTB_DNA':'Đà Nẵng','VTB_QNA':'Quảng Nam','VTB_QNG':'Quảng Ngãi','VDH_BDI':'Bình Định',
           'VDH_PYE':'Phú Yên','VDH_KHH':'Khánh Hòa','VDH_BTH':'Bình Thuận','VDH_BRV':'Bà Rịa',
           'VTB_DNA_TK':'Đà Nẵng (Tại kho)','VDH_KHH_TK':'Khánh Hòa (Tại kho)'}

NV_TAINHA, TN_LIST, NV_TAIKHO = [], [], []
for m, d in ROS.items():
    if m in BO_QLDV: continue
    pb, cv = str(d['Tên Phòng Ban']), str(d['Tên Chức Vụ'])
    tainha = ('Tại Nhà' in pb) or (m in LOC_TAINHA)
    if tainha and cv in ('Nhân Viên', 'Cộng Tác Viên'): NV_TAINHA.append(m)
    elif tainha and cv in ('Quản Lý Dịch Vụ', 'Trưởng Ca'): TN_LIST.append(m)
    elif 'Tại Kho' in pb and cv in ('Quản Lý Dịch Vụ', 'Trưởng Ca'):
        if m in TN_TAIKHO: TN_LIST.append(m)      # 4 người anh Thu chỉ định
    elif 'Tại Kho' in pb and cv == 'Nhân Viên': NV_TAIKHO.append(m)

# 12 người trong file cũ nay chuyển sang Tại Kho -> giữ điểm T1..T7, từ T8 sang nhóm thu nhập
CHUYEN_TAIKHO = set(NV_TAIKHO)

print(f"PHẠM VI: T1..T{THANG_CUOI} · lương có tới T{MIN_NOPAY-1} · ngày chốt {NGAY_CHOT}")
assert TN_TAIKHO <= set(TN_LIST), f'thiếu trong TN_LIST: {TN_TAIKHO - set(TN_LIST)}'
_tk_ql = {m for m, d in ROS.items() if 'Tại Kho' in str(d['Tên Phòng Ban'])
          and str(d['Tên Chức Vụ']).strip() in ('Quản Lý Dịch Vụ', 'Trưởng Ca')}
assert _tk_ql <= (BO_QLDV | TN_TAIKHO), \
    ('QLDV/Trưởng ca Tại Kho MỚI chưa có quyết định: %s — phải hỏi anh Thu, '
     'không được âm thầm bỏ hay âm thầm thêm' % sorted(_tk_ql - BO_QLDV - TN_TAIKHO))
print(f"  BỎ khỏi app/web: {len(BO_QLDV)} QLDV/Trưởng ca phòng ban Tại Kho = {sorted(BO_QLDV)}")
assert not (set(TN_LIST) & set(NV_TAINHA) & set(NV_TAIKHO)), 'người nằm 2 nhóm'
_tc = [x for x in TN_LIST if str(ROS[x]['Tên Chức Vụ']).strip() == 'Trưởng Ca']
print(f"  TN: {len(TN_LIST)-len(_tc)} QLDV + {len(_tc)} Trưởng Ca (chấm từ T{TRUONGCA_TU})"
      f" · trong đó {len(TN_TAIKHO)} người phòng ban Tại Kho chấm theo kho mẹ")
print(f"ROSTER: NV tại nhà={len(NV_TAINHA)}  TN={len(TN_LIST)}  NV tại kho={len(NV_TAIKHO)}  bỏ QLDV={len(BO_QLDV)}")

# ══════════════════════════════════════════════════════════════════
# 2. DATA TỪ GOOGLE SHEET
# ══════════════════════════════════════════════════════════════════
gs = openpyxl.load_workbook(XLSX_GS, data_only=True)

# --- map mã siêu thị -> mã kho (từ tab 6) ---
w6 = gs['6.TỈ LỆ TIẾP CẬN CHI NHÁNH']
ST2KHO = {}
for r in range(2, w6.max_row + 1):
    st, nm = w6.cell(row=r, column=2).value, w6.cell(row=r, column=3).value
    k = khocode(nm)
    if st is not None and k: ST2KHO[ma(st)] = k

# --- TIẾP CẬN per NV (tab 2) ---
TC = {}
w2 = gs['2.TỈ LỆ TIẾP CẬN - NV']
for r in range(3, w2.max_row + 1):
    mth = w2.cell(row=r, column=1).value
    if not isinstance(mth, (int, float)): continue
    u, tl = ma(w2.cell(row=r, column=2).value), num(w2.cell(row=r, column=14).value)
    if u is None or tl is None: continue
    TC[(u, int(mth))] = tl

# --- KHIẾU NẠI per NV (tab 1) ---
KN = defaultdict(list)
w1 = gs[_tab(gs, '1.GYKN')]
for r in range(3, w1.max_row + 1):
    mth = w1.cell(row=r, column=1).value
    if not isinstance(mth, (int, float)): continue
    nv = str(w1.cell(row=r, column=14).value or '')
    mm = re.match(r'\s*(\d{3,7})', nv)
    if not mm: continue
    # Chỉ tính phiếu ĐÃ QUY TRÁCH NHIỆM (có Phòng ban Vi phạm) — đúng cách file anh Thu chấm:
    # phiếu của BDĐK vẫn tính cho thợ; phiếu để TRỐNG phòng ban thì KHÔNG trừ điểm.
    if not str(w1.cell(row=r, column=15).value or '').strip(): continue
    ngay = to_date(w1.cell(row=r, column=21).value)
    KN[(mm.group(1), int(mth))].append({
        'loai': str(w1.cell(row=r, column=25).value or ''),
        'chude': str(w1.cell(row=r, column=4).value or ''),
        'kho': str(w1.cell(row=r, column=12).value or ''),
        'ngay': ngay,
        'nd': str(w1.cell(row=r, column=10).value or '')[:200]})

# --- LỖI XLDĐ 1 LẦN per NV (tab 4) ---
XL = defaultdict(int)
w4 = gs[_tab(gs, '4.XỬ LÝ DD1 LẦN')]
for r in range(2, w4.max_row + 1):
    mth = w4.cell(row=r, column=1).value
    if not isinstance(mth, (int, float)): continue
    # c22 "Danh sách giao hàng" = THỢ thực hiện, dạng "33962-Nguyễn Tiến Đạt"
    mm = re.match(r'\s*(\d{3,7})\s*-', str(w4.cell(row=r, column=22).value or ''))
    if not mm: continue
    XL[(mm.group(1), int(mth))] += 1

# --- THU NHẬP per NV: Sheet tab 3 (T1..T5) + file Excel 6 tháng (T1..T7) ---
INC = defaultdict(float)            # INC[(mã, tháng)] = thu nhập tháng đó
TN_INCOME = defaultdict(float)      # tổng lũy kế (dùng tie-break / top 30% tại kho)
w3 = gs['3.THU NHẬP']
for r in range(2, w3.max_row + 1):
    mth = w3.cell(row=r, column=1).value
    if not isinstance(mth, (int, float)): continue
    u, v = ma(w3.cell(row=r, column=2).value), num(w3.cell(row=r, column=51).value, 'money')
    if u and v: INC[(u, int(mth))] += v
wex = gs['KẾT QUẢ VT NV 6 THÁNG ĐẦU NĂM ']
CHOT6T = set()                       # người ĐÃ đạt Vượt Trội kỳ 6 tháng — CHỈ để hiển thị,
                                     # KHÔNG còn giữ danh hiệu (chốt lại 22/09/2026)
for r in range(5, wex.max_row + 1):
    u = ma(wex.cell(row=r, column=5).value)
    if not u: continue
    if str(wex.cell(row=r, column=13).value or '').strip().upper().startswith('VƯỢT'): CHOT6T.add(u)
    for k in range(1, MIN_NOPAY):
        v = num(wex.cell(row=r, column=14 + 13 * (k - 1) + 9).value, 'money')
        if v and not INC.get((u, k)): INC[(u, k)] = v
# ── ĐÓNG BĂNG ĐIỂM T1–T6 (chốt anh Thu 22/09/2026) ────────────────────────────
# "Bảo lưu 6 tháng đầu" = GIỮ NGUYÊN SỐ ĐIỂM T1–T6 anh Thu đã duyệt, KHÔNG giữ danh hiệu.
# Từ T7 chấm bình thường; danh hiệu xét lại theo điểm lũy kế tới tháng mới nhất.
FROZEN = {}                          # FROZEN[(mã, tháng)] = dict 3 tiêu chí đã chốt
for r in range(5, wex.max_row + 1):
    u = ma(wex.cell(row=r, column=5).value)
    if not u: continue
    for mth in range(1, 7):
        b0 = 14 + 13 * (mth - 1)
        d1, d2, d3 = (num(wex.cell(row=r, column=b0 + i).value) for i in (2, 5, 8))
        if d1 is None and d2 is None and d3 is None: continue
        FROZEN[(u, mth)] = {
            'khieuNai': {'kq': int(num(wex.cell(row=r, column=b0 + 1).value) or 0), 'd': float(d1 or 0)},
            'tiepCan':  {'kpi': num(wex.cell(row=r, column=b0 + 3).value),
                         'kq':  num(wex.cell(row=r, column=b0 + 4).value), 'd': float(d2 or 0)},
            'xldd':     {'kq': int(num(wex.cell(row=r, column=b0 + 7).value) or 0), 'd': float(d3 or 0)}}
print(f"ĐÓNG BĂNG T1-T6: {len(FROZEN)} ô (người-tháng) lấy từ bảng 6 tháng đã chốt")

for (u, k), v in INC.items(): TN_INCOME[u] += v
for u in list(TN_INCOME): TN_INCOME[u] = round(TN_INCOME[u])
for kk in list(INC): INC[kk] = round(INC[kk])
# "tháng có đi làm":
#   T1..T6 = có THU NHẬP (Sheet tab 3 có T1-T5, file Excel anh Thu có T1-T6)
#   T7..T8 = chưa có bảng lương ở nguồn nào -> dùng: có bất kỳ data nào (tiếp cận / khiếu nại / lỗi XLĐ)
def di_lam(u, k):
    if INC.get((u, k), 0) > 0: return True
    if k >= MIN_NOPAY: return (u, k) in TC or (u, k) in KN or (u, k) in XL
    return False

# --- KPI CẤP KHO: T1..T9 lấy tab "5. CHẤT LƯỢNG", T10+ lấy tab "CHẤT LƯỢNG NEW" ---
# (chốt anh Thu 25/10/2026). Mỗi bảng 1 layout cột riêng -> khai báo rõ ràng, có assert.
VD = defaultdict(dict)      # VD[kho][crit][T#] = [kpi, kq, "Đạt"/"Không đạt"]

def _sao(kq, kpi, tlht):
    """Ô 'Phục vụ 5 Sao' đôi khi bị Excel lưu thành NGÀY (vd 3.06 -> 03/06/2026).
    Khi đó suy lại số thật = KPI x Tỷ lệ hoàn thành. Cột ĐÁNH GIÁ vẫn đúng nên điểm không đổi."""
    if isinstance(kq, (datetime.datetime, datetime.date)):
        return round(kpi * tlht, 4) if (kpi is not None and tlht is not None) else None
    return num(kq)

# layout: crit -> (cột TỶ LỆ/KẾT QUẢ, cột KPI, cột TỶ LỆ HOÀN THÀNH, cột ĐÁNH GIÁ)
MAP_OLD = {'dungHen': (6, 7, 8, 9), 'tayNghe': (12, 13, 14, 15), 'xldd': (18, 19, 20, 21),
           '5sao': (22, 23, 24, 25), 'tho5s': (28, 29, 30, 31)}
MAP_NEW = {'5sao': (7, 8, 9, 10), 'dungHen': (11, 12, 13, 14), 'tayNghe': (17, 18, 19, 20),
           'tho5s': (23, 24, 25, 26), 'xldd': (32, 33, 34, 35)}

def doc_chatluong(ws, cot_thang, cot_kho, dong_dau, MAP, chi_thang=None):
    n = 0
    for r in range(dong_dau, ws.max_row + 1):
        mm = re.match(r'Tháng\s*(\d+)$', str(ws.cell(row=r, column=cot_thang).value or '').strip())
        if not mm: continue
        mth = int(mm.group(1))
        if mth not in MONTHS: continue
        if chi_thang is not None and mth not in chi_thang: continue
        k = khocode(ws.cell(row=r, column=cot_kho).value)
        if not k: continue
        for crit, (ck, cp, ct, cd) in MAP.items():
            kpi, tlht = num(ws.cell(row=r, column=cp).value), num(ws.cell(row=r, column=ct).value)
            kq = _sao(ws.cell(row=r, column=ck).value, kpi, tlht) if crit == '5sao' \
                 else num(ws.cell(row=r, column=ck).value)
            dg = ws.cell(row=r, column=cd).value
            dg = str(dg).strip() if dg else ''
            if crit == 'dungHen' and kq is not None:   # sheet lưu TỶ LỆ TRỄ -> đổi sang ĐÚNG HẸN
                kq, kpi = 1 - kq, (1 - kpi if kpi is not None else None)
            if not dg:
                if crit == 'xldd':
                    # CHỐT anh Thu 25/10/2026: XLĐ 1 lần THIẾU DATA -> TỰ ĐỘNG ĐẠT (2đ).
                    # Giữ nguyên tỷ lệ/KPI nếu Sheet có, chỉ bổ sung kết luận Đạt.
                    dg = 'Đạt'
                elif crit in ('dungHen', 'tayNghe', 'tho5s') and mth <= 6:
                    # T1..T6: KPI ghi "Không tính, mặc định có điểm"
                    dg, kq, kpi = 'Đạt', None, None
                else:
                    continue                            # không có đánh giá -> KHÔNG chấm tiêu chí đó
            VD[k].setdefault(crit, {})['T%d' % mth] = [kpi, kq,
                'Đạt' if dg.upper().startswith('ĐẠT') else 'Không đạt']
            n += 1
    return n

# Tháng nào bảng CŨ có thì lấy bảng cũ (anh Thu chốt: T1-T9 lấy '5. CHẤT LƯỢNG'),
# tháng nào bảng cũ KHÔNG có thì lấy 'CHẤT LƯỢNG NEW'. Tự đúng cho T11, T12...
def _thang_co(ws, cot_thang, dong_dau):
    s_ = set()
    for r in range(dong_dau, ws.max_row + 1):
        mm = re.match(r'Tháng\s*(\d+)$', str(ws.cell(row=r, column=cot_thang).value or '').strip())
        if mm: s_.add(int(mm.group(1)))
    return s_

_co_old = _thang_co(gs[_tab(gs, '5. CHẤT LƯỢNG')], 1, 3)
T_OLD = [m for m in MONTHS if m in _co_old]
T_NEW = [m for m in MONTHS if m not in _co_old]
n_old = doc_chatluong(gs[_tab(gs, '5. CHẤT LƯỢNG')], 1, 3, 3, MAP_OLD, T_OLD)
n_new = doc_chatluong(gs[_tab(gs, 'CHẤT LƯỢNG NEW')], 2, 6, 5, MAP_NEW, T_NEW) if T_NEW else 0
print(f"CHẤT LƯỢNG: {n_old} ô từ '5. CHẤT LƯỢNG' (T1-T9) + {n_new} ô từ 'CHẤT LƯỢNG NEW' (T10+)")
assert n_old > 0 and (not T_NEW or n_new > 0), 'đọc KPI cấp kho THẤT BẠI — layout cột đã đổi'

# --- 1 ĐỔI 1 (tab 7) + BH TRỌN ĐỜI (tab 8) — tiêu chí mới, xét TỪ T9 ---
for crit, dau in (('doi1', '7.. CL 1 ĐỔI 1'), ('trondoi', '8. CL BH TRỌN ĐỜI')):
    ws = gs[_tab(gs, dau)]
    for r in range(4, ws.max_row + 1):
        mth = ws.cell(row=r, column=1).value
        if not isinstance(mth, (int, float)): continue
        mth = int(mth)
        if mth not in MONTHS or mth < CL2_TU: continue
        k = khocode(ws.cell(row=r, column=3).value)
        if not k: continue                              # bỏ dòng TỔNG CỘNG
        dg = str(ws.cell(row=r, column=11).value or '').strip()
        if not dg: continue
        VD[k].setdefault(crit, {})['T%d' % mth] = [
            num(ws.cell(row=r, column=4).value), num(ws.cell(row=r, column=7).value),
            'Đạt' if dg.upper().startswith('ĐẠT') else 'Không đạt']
print(f"1 ĐỔI 1 / BH TRỌN ĐỜI (từ T{CL2_TU}): "
      f"{sum(len(v.get('doi1', {})) for v in VD.values())} + "
      f"{sum(len(v.get('trondoi', {})) for v in VD.values())} ô")

# --- SCDV (tab 9) ---
w9 = gs['9.SỬA CHỮA KHÁCH LẺ']
for r in range(4, w9.max_row + 1):
    mth = w9.cell(row=r, column=1).value
    if not isinstance(mth, (int, float)): continue
    k = khocode(w9.cell(row=r, column=3).value)
    if not k: continue
    tgt, dt = num(w9.cell(row=r, column=4).value, 'money'), num(w9.cell(row=r, column=15).value, 'money')
    dg = str(w9.cell(row=r, column=19).value or '')
    VD[k].setdefault('scdv', {})['T%d' % int(mth)] = [tgt, dt, 'Đạt' if 'ĐẠT' in dg.upper() and 'CHƯA' not in dg.upper() else 'Không đạt']

print(f"DATA: TC={len(TC)}  KN={sum(len(v) for v in KN.values())}  XL={sum(XL.values())}  kho có KPI={len(VD)}")

# ══════════════════════════════════════════════════════════════════
# 3. CHẤM ĐIỂM NHÂN VIÊN TẠI NHÀ
# ══════════════════════════════════════════════════════════════════
# ngưỡng TB kho = trung bình cộng tỷ lệ tiếp cận của các NV ĐANG XÉT trong kho (chốt anh Thu)
THRESH = {}
for mth in MONTHS:
    grp = defaultdict(list)
    for m in NV_TAINHA:
        v = TC.get((m, mth))
        if v is not None: grp[kho_of(m)].append(v)
    for k, vs in grp.items(): THRESH[(k, mth)] = sum(vs) / len(vs)

NVOUT = {}
for m in NV_TAINHA:
    k, thang = kho_of(m), {}
    for mth in MONTHS:
        # T1–T6: lấy ĐÚNG số anh Thu đã chốt, không tính lại.
        fr = FROZEN.get((m, mth)) if mth <= 6 else None
        if fr:
            thang['T%d' % mth] = {'tc': {c: dict(v) for c, v in fr.items()},
                                  'diem': fr['khieuNai']['d'] + fr['tiepCan']['d'] + fr['xldd']['d']}
            continue
        tc = TC.get((m, mth))
        # THÁNG CÓ ĐI LÀM (có thu nhập) mới chấm điểm — đúng cách file anh Thu đang chấm.
        # Thiếu số tiếp cận thì CHỈ tiêu chí Tiếp cận bị 0đ, Khiếu nại / XLĐ1L vẫn chấm bình thường.
        if not di_lam(m, mth):
            continue
        th = THRESH.get((k, mth))
        nkn, nxl = len(KN.get((m, mth), [])), XL.get((m, mth), 0)
        d1 = 2.0 if nkn == 0 else 0.0
        d2 = 2.0 if (tc is not None and th is not None and tc >= th - 1e-12) else 0.0
        d3 = 2.0 if nxl == 0 else 0.0
        thang['T%d' % mth] = {'tc': {
            'khieuNai': {'kq': nkn, 'd': d1},
            'tiepCan':  {'kpi': round(th, 4) if th else None,
                         'kq': (round(tc, 4) if tc is not None else None), 'd': d2},
            'xldd':     {'kq': nxl, 'd': d3}}, 'diem': d1 + d2 + d3}
    nMonths = len(thang)
    diemLK = {c: sum(thang['T%d' % x]['tc'][c]['d'] for x in CUM if 'T%d' % x in thang)
              for c in ('khieuNai', 'tiepCan', 'xldd')}
    NVOUT[m] = {'ma': m, 'ten': ROS[m]['Tên Nhân Viên'], 'chucVu': ROS[m]['Tên Chức Vụ'],
                'kho': k, 'tinh': TEN_KHO.get(k, k), 'vung': 'VTB' if k.startswith('VTB') else 'VDH',
                'trangThai': ROS[m]['Trạng thái'], 'vaoLam': (ROS[m]['Ngày Vào Làm'].strftime('%d/%m/%Y')
                    if isinstance(ROS[m]['Ngày Vào Làm'], datetime.datetime) else str(ROS[m]['Ngày Vào Làm'] or '')[:10]),
                'diemLK': diemLK, 'diem': sum(diemLK.values()), 'thang': thang,
                'soThangData': nMonths, 'duDieuKien': nMonths >= MIN_MONTHS,
                'thuNhap': TN_INCOME.get(m, 0.0)}

# xếp hạng trong kho + quota 30%
def rank_and_quota(mode):
    res = {}
    byk = defaultdict(list)
    for m, n in NVOUT.items(): byk[n['kho']].append(n)
    for k, mem in byk.items():
        elig = [x for x in mem if x['duDieuKien']]
        elig.sort(key=lambda x: (-x['diem'], -x['thuNhap']))
        q = len(elig) * 0.30
        nq = {'floor': math.floor(q), 'round': round(q), 'ceil': math.ceil(q)}[mode]
        vt = {x['ma'] for x in elig[:nq]}
        for x in mem:
            pts = [y['diem'] for y in mem]
            res[x['ma']] = {'xepHang': 1 + sum(1 for p in pts if p > x['diem']), 'vuotTroi': x['ma'] in vt}
    return res

RANKS = {mo: rank_and_quota(mo) for mo in ('floor', 'round', 'ceil')}
for m, n in NVOUT.items():
    n['xepHang'] = RANKS['floor'][m]['xepHang']
    n['vt_floor'] = RANKS['floor'][m]['vuotTroi']
    n['vt_round'] = RANKS[QUOTA_MODE][m]['vuotTroi']   # khoá kết quả chính thức theo QUOTA_MODE

# ══════════════════════════════════════════════════════════════════
# 4. CHẤM ĐIỂM TRƯỞNG NHÓM (6 tiêu chí)
# ══════════════════════════════════════════════════════════════════
CRIT_TN = [('5sao', 4), ('dungHen', 2), ('tayNghe', 2), ('xldd', 2), ('tho5s', 2), ('scdv', 2),
           ('doi1', 2), ('trondoi', 2)]      # 2 tiêu chí mới, 2đ, xét từ T9 (chốt 25/10)
def pt_of(c, base, mth): return 4 if (c == 'scdv' and mth >= SCDV_4D_TU) else base

TNOUT = {}
for m in TN_LIST:
    k, thang = kho_tn(m), {}
    cv_m = str(ROS[m]['Tên Chức Vụ']).strip()
    # Trưởng Ca: chức vụ mới, anh Thu chốt chỉ đánh giá TỪ T10
    mths = [x for x in MONTHS if x >= TRUONGCA_TU] if cv_m == 'Trưởng Ca' else list(MONTHS)
    assert mths, f'{m}: không còn tháng nào để chấm'
    for mth in mths:
        tc, tong = {}, 0.0
        for c, base in CRIT_TN:
            rec = VD.get(k, {}).get(c, {}).get('T%d' % mth)
            if not rec: continue
            pt = pt_of(c, base, mth)
            d = float(pt) if rec[2] == 'Đạt' else 0.0
            tc[c] = {'kpi': rec[0], 'kq': rec[1], 'd': d}
            tong += d
        if tc: thang['T%d' % mth] = {'tc': tc, 'tong': tong}
    diemLK = {c: sum(thang['T%d' % x]['tc'].get(c, {}).get('d', 0) for x in CUM if 'T%d' % x in thang)
              for c, _ in CRIT_TN}
    TNOUT[m] = {'ma': m, 'ten': ROS[m]['Tên Nhân Viên'], 'chucVu': cv_m,
                'kho': k, 'tinh': TEN_KHO.get(k, k), 'vung': 'VTB' if k.startswith('VTB') else 'VDH',
                'pbTaiKho': m in TN_TAIKHO, 'tuThang': min(mths), 'soThangCham': len(mths),
                'diemLK': diemLK, 'tongDiem': sum(diemLK.values()), 'thang': thang}
# ── XẾP HẠNG CHUNG BẢNG THEO ĐIỂM THÁNG CUỐI (anh Thu chốt 01/11) ──
#   Trưởng Ca chỉ chấm từ T10 nên so lũy kế là bất lợi; so cùng mốc T{THANG_CUOI}.
TN_HANG_THANG = THANG_CUOI
def _diem_xh(x): return x['thang'].get('T%d' % TN_HANG_THANG, {}).get('tong', -1.0)
for vung in ('VTB', 'VDH'):
    g = [t for t in TNOUT.values() if t['vung'] == vung]
    pts = [_diem_xh(x) for x in g]
    for x in g:
        x['diemXH'] = _diem_xh(x)
        x['xepHang'] = 1 + sum(1 for p in pts if p > x['diemXH'])
    assert min(pts) >= 0, f'{vung}: có TN không có điểm T{TN_HANG_THANG}'
for mth in MONTHS:
    for vung in ('VTB', 'VDH'):
        g = [t for t in TNOUT.values() if t['vung'] == vung and 'T%d' % mth in t['thang']]
        pts = [x['thang']['T%d' % mth]['tong'] for x in g]
        for x in g:
            v = x['thang']['T%d' % mth]['tong']
            x['thang']['T%d' % mth]['hang'] = 1 + sum(1 for p in pts if p > v)

# ══════════════════════════════════════════════════════════════════
# 5. NHÂN VIÊN TẠI KHO — top 30% thu nhập (T1..T5), giấu số
# ══════════════════════════════════════════════════════════════════
TKOUT = {}
byk = defaultdict(list)
for m in NV_TAIKHO: byk[kho_of(m)].append(m)
for k, mem in byk.items():
    mem.sort(key=lambda x: -TN_INCOME.get(x, 0))
    nq = round(len(mem) * 0.30)          # làm tròn gần nhất (chốt anh Thu 28/08) — thống nhất với NV tại nhà
    for i, m in enumerate(mem):
        TKOUT[m] = {'ma': m, 'ten': ROS[m]['Tên Nhân Viên'], 'kho': k, 'tinh': TEN_KHO.get(k, k),
                    'vung': 'VTB' if k.startswith('VTB') else 'VDH',
                    'chucVu': ROS[m]['Tên Chức Vụ'], 'hangThuNhap': i + 1,
                    'vuotTroi': i < nq, 'thuNhap': TN_INCOME.get(m, 0.0)}

out = {'NV': NVOUT, 'TN': TNOUT, 'TAIKHO': TKOUT, 'VDATA': {k: dict(v) for k, v in VD.items()},
       'INC': {f'{u}|T{k}': v for (u, k), v in INC.items()},
       'CHOT6T': sorted(CHOT6T),
       'THRESH': {f'{k}|T{m}': round(v, 6) for (k, m), v in THRESH.items()},
       'KN': {f'{k}|T{m}': v for (k, m), v in KN.items()},
       'meta': {'months': MONTHS, 'cum': CUM, 'minMonths': MIN_MONTHS,
                'tenKho': TEN_KHO, 'chotT8': NGAY_CHOT,
                'nopay': [x for x in MONTHS if x >= MIN_NOPAY],
                'truongCaTu': TRUONGCA_TU, 'tnHangThang': TN_HANG_THANG}}
json.dump(out, open('build_out.json', 'w', encoding='utf-8'), ensure_ascii=False)

print(f"\nKẾT QUẢ: NV tại nhà={len(NVOUT)}  TN={len(TNOUT)}  NV tại kho={len(TKOUT)}")
print(f"  Đủ điều kiện (>={MIN_MONTHS} tháng): {sum(1 for n in NVOUT.values() if n['duDieuKien'])}")
print(f"  Vượt Trội quota floor: {sum(1 for n in NVOUT.values() if n['vt_floor'])}"
      f"   |  round: {sum(1 for n in NVOUT.values() if n['vt_round'])}")
print(f"  NV tại kho đạt (top 30% thu nhập): {sum(1 for t in TKOUT.values() if t['vuotTroi'])}/{len(TKOUT)}")
print("→ build_out.json")
