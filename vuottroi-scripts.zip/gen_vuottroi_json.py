#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sinh vuottroi.json cho TAB 10 của web KẾT QUẢ VẬN HÀNH (từ build_out.json)."""
import json, math, datetime, os
from collections import defaultdict

D = json.load(open('build_out.json', encoding='utf-8'))
NV, TN, TK, INC = D['NV'], D['TN'], D['TAIKHO'], D['INC']
CHOT = set(D.get('CHOT6T', [])) & set(NV)
# 22/09/2026: 'bảo lưu 6 tháng' = GIỮ ĐIỂM T1–T6, KHÔNG giữ danh hiệu.
FINAL = {m for m, n in NV.items() if n['vt_round']}
MONTHS = D['meta']['months']                      # động theo build_out.json
CT6 = ['5sao', 'dungHen', 'tayNghe', 'xldd', 'tho5s', 'scdv', 'doi1', 'trondoi']

# ── Vượt Trội TỪNG THÁNG (quy luật gốc anh Thu, khớp 798/798 ô) ──────────
NOPAY = set(D['meta'].get('nopay') or [])         # tháng chưa có bảng lương (động)
byk = defaultdict(list)
for m, n in NV.items(): byk[n['kho']].append(m)
rankM, vtM = {}, {}
for k, mem in byk.items():
    q = round(len(mem) * 0.30)
    for mth in MONTHS:
        t = 'T%d' % mth
        pts = {x: NV[x]['thang'][t]['diem'] for x in mem if t in NV[x]['thang']}
        for x, v in pts.items():
            rankM[(x, mth)] = 1 + sum(1 for y in pts.values() if y > v)
        full = [x for x, v in pts.items() if v == 6]
        if mth in NOPAY:
            win = set(full)
        else:
            full.sort(key=lambda x: -(INC.get('%s|T%d' % (x, mth)) or 0))
            win = set(full[:q])
        for x in win: vtM[(x, mth)] = 1

bykk = defaultdict(list)
for m, t in TK.items(): bykk[t['kho']].append(m)
rankTK, vtTK = {}, {}
for k, mem in bykk.items():
    q = round(len(mem) * 0.30)
    for mth in MONTHS:
        pay = {x: INC.get('%s|T%d' % (x, mth)) for x in mem}
        pay = {x: v for x, v in pay.items() if v}
        if not pay: continue
        for i, x in enumerate(sorted(pay, key=lambda y: -pay[y])):
            rankTK[(x, mth)] = i + 1
            if i < q: vtTK[(x, mth)] = 1

# ── Người ────────────────────────────────────────────────────────────────
def thang_nv(ma_, n):
    o = {}
    for mth in MONTHS:
        mm = n['thang'].get('T%d' % mth)
        if not mm: continue
        tc = mm['tc']
        o[str(mth)] = {'d': mm['diem'], 'h': rankM.get((ma_, mth)),
                       'vt': vtM.get((ma_, mth), 0),
                       'kn': tc['khieuNai']['kq'], 'xl': tc['xldd']['kq'],
                       'tc': tc['tiepCan']['kq'], 'tb': tc['tiepCan']['kpi'],
                       'tn': INC.get('%s|T%d' % (ma_, mth))}
    return o

nguoi = []
for ma_, n in sorted(NV.items(), key=lambda x: (x[1]['vung'], x[1]['tinh'], x[1]['xepHang'])):
    nguoi.append({'ma': ma_, 'ten': n['ten'], 'cv': n['chucVu'], 'kho': n['kho'], 'tinh': n['tinh'],
                  'vung': n['vung'], 'nhom': 'nha', 'diem': n['diem'], 'hang': n['xepHang'],
                  'vt': 1 if ma_ in FINAL else 0, 'chot6t': 1 if ma_ in CHOT else 0,
                  'soThang': n['soThangData'], 'duDK': 1 if n['duDieuKien'] else 0,
                  'tn': round(n.get('thuNhap') or 0), 'thang': thang_nv(ma_, n)})
for ma_, t in sorted(TK.items(), key=lambda x: (x[1]['kho'], x[1]['hangThuNhap'])):
    th = {str(mth): {'h': rankTK.get((ma_, mth)), 'vt': vtTK.get((ma_, mth), 0),
                     'tn': INC.get('%s|T%d' % (ma_, mth))}
          for mth in MONTHS if INC.get('%s|T%d' % (ma_, mth))}
    nguoi.append({'ma': ma_, 'ten': t['ten'], 'cv': t['chucVu'], 'kho': t['kho'], 'tinh': t['tinh'],
                  'vung': t['vung'], 'nhom': 'kho', 'diem': None, 'hang': t['hangThuNhap'],
                  'vt': 1 if t['vuotTroi'] else 0, 'chot6t': 0, 'soThang': len(th), 'duDK': 1,
                  'tn': round(t.get('thuNhap') or 0), 'thang': th})

# ── Trưởng nhóm / QLDV ───────────────────────────────────────────────────
tn_out = []
for ma_, t in sorted(TN.items(), key=lambda x: (x[1]['vung'], x[1]['xepHang'])):
    th = {}
    for mth in MONTHS:
        mm = t['thang'].get('T%d' % mth)
        if not mm: continue
        th[str(mth)] = {'tong': mm['tong'], 'hang': mm.get('hang'),
                        'tc': {c: {'kpi': v['kpi'], 'kq': v['kq'], 'd': v['d']}
                               for c, v in mm['tc'].items()}}
    tn_out.append({'ma': ma_, 'ten': t['ten'], 'cv': t['chucVu'], 'kho': t['kho'], 'tinh': t['tinh'],
                   'vung': t['vung'], 'diemLK': t['diemLK'], 'tong': t['tongDiem'],
                   'hang': t['xepHang'], 'tuThang': t.get('tuThang', 1),
                   'diemXH': t.get('diemXH'), 'diemHang': t.get('diemHang'),
                   'pbTaiKho': 1 if t.get('pbTaiKho') else 0,
                   'thang': th})

# ── Tổng hợp theo kho (mỗi tháng + lũy kế) ───────────────────────────────
kho_out = {}
for k, mem in byk.items():
    n0 = NV[mem[0]]
    row = {'ma': k, 'tinh': n0['tinh'], 'vung': n0['vung'], 'nhom': 'nha',
           'n': len(mem), 'quota': round(len(mem) * 0.30),
           'lk': {'vt': sum(1 for x in mem if x in FINAL),
                  'diemTB': round(sum(NV[x]['diem'] for x in mem) / len(mem), 1)},
           'thang': {}}
    for mth in MONTHS:
        t = 'T%d' % mth
        act = [x for x in mem if t in NV[x]['thang']]
        if not act: continue
        row['thang'][str(mth)] = {
            'n': len(act), 'vt': sum(1 for x in act if vtM.get((x, mth))),
            'diemTB': round(sum(NV[x]['thang'][t]['diem'] for x in act) / len(act), 1),
            'du6': sum(1 for x in act if NV[x]['thang'][t]['diem'] == 6)}
    kho_out[k] = row
for k, mem in bykk.items():
    t0 = TK[mem[0]]
    row = {'ma': k, 'tinh': t0['tinh'], 'vung': t0['vung'], 'nhom': 'kho',
           'n': len(mem), 'quota': round(len(mem) * 0.30),
           'lk': {'vt': sum(1 for x in mem if TK[x]['vuotTroi']), 'diemTB': None}, 'thang': {}}
    for mth in MONTHS:
        act = [x for x in mem if INC.get('%s|T%d' % (x, mth))]
        if not act: continue
        row['thang'][str(mth)] = {'n': len(act), 'vt': sum(1 for x in act if vtTK.get((x, mth))),
                                  'diemTB': None, 'du6': None}
    kho_out[k] = row

out = {
    'meta': {'nam': 2026, 'thang': MONTHS, 'chotT8': D['meta'].get('chotT8', ''),
             'truongCaTu': D['meta'].get('truongCaTu'), 'tnHangThang': D['meta'].get('tnHangThang'),
             'tnHangTheo': D['meta'].get('tnHangTheo'),
             'nguon': 'Google Sheet "VTB - DH DATA 2026"',
             'capNhat': os.environ.get('VT_NGAY_CHOT') or datetime.datetime.now().strftime('%d/%m/%Y'),
             'tongNV': len(NV), 'tongTN': len(TN), 'tongTK': len(TK),
             'vtNha': len(FINAL), 'vtKho': sum(1 for x in TK.values() if x['vuotTroi']),
             'chot6t': len(CHOT),
             'critTN': {'5sao': 'Phục vụ 5 Sao', 'dungHen': 'Đúng hẹn',
                        'doi1': 'CL 1 Đổi 1', 'trondoi': 'CL BH Trọn Đời',
                        'tayNghe': 'Tay nghề chuẩn (IMEI lặp lại)', 'xldd': 'Xử lý DĐ 1 lần',
                        'tho5s': 'Thợ Chuẩn 5S', 'scdv': 'Sửa chữa khách lẻ'},
             'critNV': {'kn': 'Không góp ý/khiếu nại', 'tc': 'Tiếp cận ≥ TB kho',
                        'xl': 'Không lỗi XLĐ 1 lần'}},
    'kho': kho_out, 'nguoi': nguoi, 'tn': tn_out}
json.dump(out, open('vuottroi.json', 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
sz = len(open('vuottroi.json', encoding='utf-8').read())
print(f"→ vuottroi.json ({sz/1024:.0f} KB)")
print(f"   {len(nguoi)} người ({sum(1 for x in nguoi if x['nhom']=='nha')} tại nhà + "
      f"{sum(1 for x in nguoi if x['nhom']=='kho')} tại kho) · {len(tn_out)} TN · {len(kho_out)} kho")
print(f"   Vượt Trội: {out['meta']['vtNha']} tại nhà + {out['meta']['vtKho']} tại kho")
