#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GIAI ĐOẠN 2 — chấm lại điểm NHÂN VIÊN TẠI NHÀ bằng logic độc lập, so từng ô với app."""
import openpyxl, re, json
from collections import defaultdict
exec(open('audit.py',encoding='utf-8').read().split('# ── 1. DANH')[0].split('wb = openpyxl')[0])  # lấy hàm n(), mma(), kcode()

A = json.load(open('audit_raw.json', encoding='utf-8'))
D = json.load(open('build_out.json', encoding='utf-8'))
wb = openpyxl.load_workbook('DATA.xlsx', data_only=True)
TC = {tuple(k.split('|')): v for k, v in A['TC'].items()}
TC = {(a, int(b)): v for (a, b), v in TC.items()}
KN = {(k.split('|')[0], int(k.split('|')[1])): v for k, v in A['KN'].items()}
XL = {(k.split('|')[0], int(k.split('|')[1])): v for k, v in A['XL'].items()}
NHA, TNL, KHO = A['NHA'], A['TN'], A['KHO']
MONTHS = list(range(1, 11)); LOI = []
def err(x): LOI.append(x)

# ── THU NHẬP độc lập ────────────────────────────────────────────────
INC = defaultdict(float)
ws = wb['3.THU NHẬP']
for r in range(2, ws.max_row + 1):
    mt = ws.cell(r, 1).value
    if not isinstance(mt, (int, float)): continue
    u, v = mma(ws.cell(r, 2).value), n(ws.cell(r, 51).value)
    if u and v: INC[(u, int(mt))] += v
wex = wb['KẾT QUẢ VT NV 6 THÁNG ĐẦU NĂM ']
CHOT = set()
for r in range(5, wex.max_row + 1):
    u = mma(wex.cell(r, 5).value)
    if not u: continue
    if str(wex.cell(r, 13).value or '').strip().upper().startswith('VƯỢT'): CHOT.add(u)
    for k in range(1, 8):
        v = n(wex.cell(r, 14 + 13 * (k - 1) + 9).value)
        if v and not INC.get((u, k)): INC[(u, k)] = v
INC = {k: round(v) for k, v in INC.items()}
print(f"[5] THU NHẬP {len(INC)} ô · BẢO LƯU 6T {len(CHOT)} người")
if len(INC) != len(D['INC']): err(f"số ô thu nhập: {len(INC)} vs app {len(D['INC'])}")
for k, v in INC.items():
    av = D['INC'].get(f'{k[0]}|T{k[1]}')
    if av is None or abs(av - v) > 0.5: err(f"thu nhập {k}: audit {v} vs app {av}")
if CHOT != set(D['CHOT6T']): err(f"bảo lưu lệch: {CHOT ^ set(D['CHOT6T'])}")

# ── ĐÓNG BĂNG T1–T6 (đọc lại tab 13 bằng code riêng) ──
FROZ = {}
for r in range(5, wex.max_row + 1):
    u = mma(wex.cell(r, 5).value)
    if not u: continue
    for mth in range(1, 7):
        b0 = 14 + 13 * (mth - 1)
        ds = [n(wex.cell(r, b0 + i).value) for i in (2, 5, 8)]
        if all(x is None for x in ds): continue
        FROZ[(u, mth)] = sum(float(x or 0) for x in ds)
bad = 0
for r in range(5, wex.max_row + 1):
    u = mma(wex.cell(r, 5).value)
    if not u or u not in D['NV']: continue
    goc = n(wex.cell(r, 11).value)
    if goc is None: continue
    moi = sum(D['NV'][u]['thang'][f'T{k}']['diem'] for k in range(1, 7) if f'T{k}' in D['NV'][u]['thang'])
    if abs(moi - goc) > 1e-6: err(f"đóng băng {u}: cột 11 = {goc} vs app = {moi}"); bad += 1
print(f"[6b] ĐÓNG BĂNG T1-T6: {len(FROZ)} ô · lệch cột 11: {bad}")

def di_lam(u, k):
    if INC.get((u, k), 0) > 0: return True
    if k >= 10: return (u, k) in TC or (u, k) in KN or (u, k) in XL
    return False

# ── NGƯỠNG TB KHO ───────────────────────────────────────────────────
kho_of = {m: (D['NV'].get(m) or D['TN'].get(m) or D['TAIKHO'].get(m))['kho'] for m in NHA + TNL + KHO}
TH = {}
for mth in MONTHS:
    g = defaultdict(list)
    for m in NHA:
        if (m, mth) in TC: g[kho_of[m]].append(TC[(m, mth)])  # ĐÃ SỬA: không lọc di_lam (khớp file anh Thu 68/71)
    for k, vs in g.items(): TH[(k, mth)] = sum(vs) / len(vs)
for (k, mth), v in TH.items():
    av = D['THRESH'].get(f'{k}|T{mth}')
    if av is None or abs(av - v) > 1e-5: err(f"ngưỡng {k} T{mth}: audit {v:.6f} vs app {av}")
print(f"[6] NGƯỠNG TB KHO {len(TH)} ô · so app: {'KHỚP' if not [x for x in LOI if 'ngưỡng' in x] else 'LỆCH'}")

# ── CHẤM ĐIỂM NV ────────────────────────────────────────────────────
NV = {}
for m in NHA:
    k, th = kho_of[m], {}
    for mth in MONTHS:
        if mth <= 6 and (m, mth) in FROZ:
            th[mth] = {'diem': FROZ[(m, mth)], 'kn': None, 'tc': None, 'xl': None}
            continue
        if not di_lam(m, mth): continue
        kn = 2.0 if KN.get((m, mth), 0) == 0 else 0.0
        tcv = TC.get((m, mth))
        ng = TH.get((k, mth))
        tc = 2.0 if (tcv is not None and ng is not None and tcv >= ng) else 0.0
        xl = 2.0 if XL.get((m, mth), 0) == 0 else 0.0
        th[mth] = {'diem': kn + tc + xl, 'kn': kn, 'tc': tc, 'xl': xl}
    NV[m] = {'kho': k, 'thang': th, 'diem': sum(x['diem'] for x in th.values()),
             'so': len(th), 'du': len(th) >= 5}

for m, a in NV.items():
    b = D['NV'][m]
    if abs(a['diem'] - b['diem']) > 1e-6: err(f"{m} ĐIỂM: audit {a['diem']} vs app {b['diem']}")
    if a['so'] != b['soThangData']: err(f"{m} số tháng: audit {a['so']} vs app {b['soThangData']}")
    if a['du'] != b['duDieuKien']: err(f"{m} đủ ĐK: audit {a['du']} vs app {b['duDieuKien']}")
    for mth, x in a['thang'].items():
        y = b['thang'].get(f'T{mth}')
        if not y: err(f"{m} T{mth} app thiếu tháng"); continue
        if abs(x['diem'] - y['diem']) > 1e-6: err(f"{m} T{mth} điểm: {x['diem']} vs {y['diem']}")
        if x['kn'] is None: continue
        for c, kk in (('kn','khieuNai'),('tc','tiepCan'),('xl','xldd')):
            if abs(x[c] - y['tc'][kk]['d']) > 1e-6: err(f"{m} T{mth} {kk}: {x[c]} vs {y['tc'][kk]['d']}")
    if len(a['thang']) != len(b['thang']): err(f"{m} số tháng chi tiết lệch")

# ── XẾP HẠNG + VƯỢT TRỘI ────────────────────────────────────────────
byk = defaultdict(list)
for m in NHA: byk[NV[m]['kho']].append(m)
VT = set()
for k, mem in byk.items():
    pts = [NV[x]['diem'] for x in mem]
    for x in mem: NV[x]['hang'] = 1 + sum(1 for p in pts if p > NV[x]['diem'])
    elig = [x for x in mem if NV[x]['du']]
    elig.sort(key=lambda x: (-NV[x]['diem'], -sum(INC.get((x, mm), 0) for mm in MONTHS)))
    q = round(len(elig) * 0.30)      # mẫu số = người ĐỦ ĐIỀU KIỆN (khớp build.py)
    VT |= set(elig[:q])
for m in NHA:
    if NV[m]['hang'] != D['NV'][m]['xepHang']: err(f"{m} xếp hạng: {NV[m]['hang']} vs {D['NV'][m]['xepHang']}")
appVT = {m for m in NHA if D['NV'][m]['vt_round']}
if VT != appVT: err(f"VƯỢT TRỘI (chưa bảo lưu) lệch: audit-only={sorted(VT-appVT)} app-only={sorted(appVT-VT)}")
print(f"[7] NV: {len(NHA)} người · VT trước bảo lưu {len(VT)} · + bảo lưu = {len(VT|(CHOT&set(NHA)))}")
print()
print('LỖI GIAI ĐOẠN 2:', ('\n  - ' + '\n  - '.join(LOI)) if LOI else 'KHÔNG CÓ ✅')
