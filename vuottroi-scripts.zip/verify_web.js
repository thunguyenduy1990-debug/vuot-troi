const {chromium}=require('playwright');
(async()=>{
 const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1243/chrome-linux64/chrome'});
 for (const [nhan,chan] of [['CÓ vuottroi.json',false],['CHẶN vuottroi.json (offline/PDF)',true]]){
  const p=await b.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  p.on('console',m=>{if(m.type()==='error')errs.push('CONSOLE '+m.text())});
  if(chan) await p.route('**/vuottroi.json',r=>r.abort());
  await p.goto('http://localhost:8899/index.html',{waitUntil:'networkidle'});
  await p.waitForTimeout(1600);
  await p.evaluate(()=>[...document.querySelectorAll('#tabbar *')].find(e=>/VƯỢT TRỘI/.test(e.textContent)).click());
  await p.waitForTimeout(1600);
  const t=await p.$eval('#m9',e=>e.innerText);
  console.log(`${nhan}\n   ĐẠT ${(t.match(/ĐẠT VƯỢT TRỘI\s*\n?([\d\/]+)/)||[])[1]} · cập nhật ${(t.match(/cập nhật ([\d\/]+)/)||[])[1]} · ${(t.match(/Tháng \d+ chốt data tới[\s\S]{0,13}/)||[''])[0].replace(/\n/g,' ')} · lỗi JS: ${errs.length?errs.slice(0,2).join(';'):'không'}`);
  console.log('   cột:',(t.match(/KHO \/ ĐƠN VỊ[\s\S]{0,70}/)||[''])[0].replace(/\n/g,' '));
  if(!chan){
   const sl=await p.evaluate(()=>{try{return slideModel(ST).map(x=>x.id).join(', ')}catch(e){return 'ERR '+e.message}});
   console.log('   slides:',sl);
   const tn=await p.evaluate(()=>{const tr=[...document.querySelectorAll('#m9 table')].find(x=>/TRƯỞNG NHÓM/.test(x.innerText)||/HẠNG/.test(x.innerText)); return tr?tr.querySelectorAll('thead th').length+' cột tiêu đề bảng TN':'?'});
   console.log('   bảng TN:',tn);
   const v=await p.evaluate(async()=>{const o={};for(const x of ['TONG','Vùng Trung Bộ','Vùng Duyên Hải']){const s=document.getElementById('fVung');s.value=x;s.dispatchEvent(new Event('change',{bubbles:true}));await new Promise(r=>setTimeout(r,600));o[x]=(document.getElementById('m9').innerText.match(/ĐẠT VƯỢT TRỘI\s*\n?([\d\/]+)/)||[])[1];}return o});
   console.log('   lọc vùng:',JSON.stringify(v));
  }
  await p.close();
 }
 await b.close();
})();
