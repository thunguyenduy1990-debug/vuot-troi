#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SOÁT ĐỘC LẬP 100% — đọc lại DATA.xlsx bằng logic viết riêng, KHÔNG dùng lại build.py,
rồi đối chiếu từng ô với build_out.json. Mục tiêu: tìm ra chỗ app tính sai.
"""
import openpyxl, re, json, datetime
from collections import defaultdict

MONTHS = list(range(1, 11))
BO = {'153917', '170083', '3177', '39675', '66577'}  # chốt 02/11: bỏ hẳn QLDV/Tr.ca Tại Kho
TN_TK = set()                                        # không còn ai phòng ban Tại Kho được xét
LOC = {'79986'}
LOI = []
def err(x): LOI.append(x)

def mma(v):
    if v is None: return None
    if isinstance(v, float) and v == int(v): return str(int(v))
    return str(v).strip()

def n(v):
    """parser số ĐỘC LẬP, viết lại từ đầu."""
    if v is None or v == '': return None
    if isinstance(v, (int, float)): return float(v)
    s = str(v).strip().replace(' ', '').replace(' ', '')
    if s in ('-', '—', 'NA', 'N/A'): return None
    pct = s.endswith('%')
    if pct: s = s[:-1]
    s = re.sub(r'[^\d,.\-]', '', s)
    if not s or s in ('-',): return None
    c, d = s.count(','), s.count('.')
    if c and d:
        sep = ',' if s.rfind(',') > s.rfind('.') else '.'
        s = s.replace(',' if sep == '.' else '.', '').replace(sep, '.')
    elif c or d:
        sep = ',' if c else '.'
        parts = s.split(sep)
        if len(parts) > 2 or len(parts[-1]) == 3: s = s.replace(sep, '')
        else: s = s.replace(sep, '.')
    try: f = float(s)
    except ValueError: return None
    return f / 100 if pct else f

def kcode(s):
    m = re.search(r'(VTB|VDH)_[A-Z]{3}', str(s or ''))
    return m.group(0) if m else None

def _tb(wb, dau):
    hit=[n for n in wb.sheetnames if n.strip().startswith(dau)]
    assert len(hit)==1, f'tab {dau!r}: {hit}'
    return hit[0]

wb = openpyxl.load_workbook('DATA.xlsx', data_only=True)
D  = json.load(open('build_out.json', encoding='utf-8'))

# ── 1. DANH SÁCH NHÂN SỰ ────────────────────────────────────────────
ws = wb['DANH SÁCH NHÂN SỰ']
H = {str(ws.cell(1, c).value).strip(): c for c in range(1, 15) if ws.cell(1, c).value}
ROS = {}
for r in range(2, ws.max_row + 1):
    if not ws.cell(r, 1).value: continue
    ROS[mma(ws.cell(r, H['Mã Nhân Viên']).value)] = {k: ws.cell(r, c).value for k, c in H.items()}
TK_ST = {'VDH_KHH - Kho BHSC CE Khánh Hòa': 'VDH_KHH_TK',
         'VTB_DNA - Kho BHSC CE Đà Nẵng':   'VTB_DNA_TK'}
def kho_of(m):
    st = str(ROS[m]['Tên Siêu Thị'])
    for k, v in TK_ST.items():
        if st.startswith(k): return v
    return kcode(st)

NHA, TNL, KHO = [], [], []
for m, d in ROS.items():
    if m in BO: continue
    pb, cv = str(d['Tên Phòng Ban']), str(d['Tên Chức Vụ'])
    nha = ('Tại Nhà' in pb) or (m in LOC)
    if nha and cv in ('Nhân Viên', 'Cộng Tác Viên'): NHA.append(m)
    elif nha and cv in ('Quản Lý Dịch Vụ', 'Trưởng Ca'): TNL.append(m)
    elif 'Tại Kho' in pb and cv in ('Quản Lý Dịch Vụ', 'Trưởng Ca'):
        if m in TN_TK: TNL.append(m)
    elif 'Tại Kho' in pb and cv == 'Nhân Viên': KHO.append(m)

print(f"[1] ROSTER  file={len(ROS)}  → tại nhà {len(NHA)} · TN {len(TNL)} · tại kho {len(KHO)} · bỏ {len(BO)}")
if len(NHA) != len(D['NV']): err(f"số NV tại nhà: audit {len(NHA)} vs app {len(D['NV'])}")
if len(TNL) != len(D['TN']): err(f"số TN: audit {len(TNL)} vs app {len(D['TN'])}")
if len(KHO) != len(D['TAIKHO']): err(f"số tại kho: audit {len(KHO)} vs app {len(D['TAIKHO'])}")
if set(NHA) != set(D['NV']): err(f"lệch danh sách NV: {set(NHA)^set(D['NV'])}")
if set(TNL) != set(D['TN']): err(f"lệch danh sách TN: {set(TNL)^set(D['TN'])}")
if set(KHO) != set(D['TAIKHO']): err(f"lệch danh sách tại kho: {set(KHO)^set(D['TAIKHO'])}")
for m in NHA + TNL + KHO:
    k = kho_of(m)
    # TN/Trưởng ca phòng ban Tại Kho: chấm theo KHO MẸ (tab 5/9 chỉ có 12 kho)
    if m in TNL and k and k.endswith('_TK'): k = k[:-3]
    app = (D['NV'].get(m) or D['TN'].get(m) or D['TAIKHO'].get(m))['kho']
    if k != app: err(f"{m} kho: audit {k} vs app {app}")

# ── 2. TIẾP CẬN (tab 2) ─────────────────────────────────────────────
ws = wb['2.TỈ LỆ TIẾP CẬN - NV']
TC = {}
dup = 0
for r in range(3, ws.max_row + 1):
    mt = ws.cell(r, 1).value
    if not isinstance(mt, (int, float)): continue
    u, v = mma(ws.cell(r, 2).value), n(ws.cell(r, 14).value)
    if u is None or v is None: continue
    if (u, int(mt)) in TC and abs(TC[(u, int(mt))] - v) > 1e-9: dup += 1
    TC[(u, int(mt))] = v
print(f"[2] TIẾP CẬN  {len(TC)} ô · dòng trùng khác giá trị: {dup}")

# ── 3. KHIẾU NẠI (tab 1) ────────────────────────────────────────────
ws = wb[_tb(wb,'1.GYKN')]
KN = defaultdict(int)
tong_phieu = co_pb = 0
for r in range(3, ws.max_row + 1):
    mt = ws.cell(r, 1).value
    if not isinstance(mt, (int, float)): continue
    tong_phieu += 1
    mm = re.match(r'\s*(\d{3,7})', str(ws.cell(r, 14).value or ''))
    if not mm: continue
    if not str(ws.cell(r, 15).value or '').strip(): continue
    co_pb += 1
    KN[(mm.group(1), int(mt))] += 1
print(f"[3] KHIẾU NẠI  tổng phiếu {tong_phieu} · có Phòng ban Vi phạm {co_pb} · {len(KN)} ô NV-tháng")

# ── 4. LỖI XLĐ (tab 4) ──────────────────────────────────────────────
ws = wb[_tb(wb,'4.XỬ LÝ DD1 LẦN')]
XL = defaultdict(int)
for r in range(2, ws.max_row + 1):
    mt = ws.cell(r, 1).value
    if not isinstance(mt, (int, float)): continue
    mm = re.match(r'\s*(\d{3,7})\s*-', str(ws.cell(r, 22).value or ''))
    if mm: XL[(mm.group(1), int(mt))] += 1
print(f"[4] LỖI XLĐ  {sum(XL.values())} lỗi · {len(XL)} ô NV-tháng")

json.dump({'TC': {f'{a}|{b}': v for (a, b), v in TC.items()},
           'KN': {f'{a}|{b}': v for (a, b), v in KN.items()},
           'XL': {f'{a}|{b}': v for (a, b), v in XL.items()},
           'ROS': list(ROS), 'NHA': NHA, 'TN': TNL, 'KHO': KHO},
          open('audit_raw.json', 'w', encoding='utf-8'), ensure_ascii=False)
print()
print('LỖI GIAI ĐOẠN 1:', '\n  - '.join(['']+LOI) if LOI else 'KHÔNG CÓ')
