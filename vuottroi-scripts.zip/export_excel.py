#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""XUẤT FILE: VƯỢT TRỘI 2026 — 10 THÁNG ĐẦU NĂM BHSC (theo mẫu anh Thu gửi)"""
import json, math, openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from collections import defaultdict

D   = json.load(open('build_out.json', encoding='utf-8'))
NV, TN, TK, VD = D['NV'], D['TN'], D['TAIKHO'], D['VDATA']
MONTHS = list(range(1, 11))

# ── Vượt Trội chốt: giữ 6 tháng + quota làm tròn gần nhất (phương án B anh Thu chọn) ──
CHOT  = set(D.get('CHOT6T', [])) & set(NV)
# 22/09/2026: 'bảo lưu 6 tháng' = GIỮ ĐIỂM T1–T6, KHÔNG giữ danh hiệu.
FINAL = {m for m, n in NV.items() if n['vt_round']}

GREEN  = PatternFill('solid', fgColor='FF00B050')
ZEBRA    = PatternFill('solid', fgColor='FFF7FAFD')   # kẻ sọc nhẹ cho dễ dò dòng
CUMF     = PatternFill('solid', fgColor='FFFFF9E6')   # nền khối LŨY KẾ
MONTHHDR = PatternFill('solid', fgColor='FFD9E7F7')   # tiêu đề tháng
BLUE   = PatternFill('solid', fgColor='FF00B0F0')
NAVY   = PatternFill('solid', fgColor='FF0B2E63')
YELLOW = PatternFill('solid', fgColor='FFFFFF00')
GREY   = PatternFill('solid', fgColor='FFF2F2F2')
ORANGE = PatternFill('solid', fgColor='FFFFC000')
WF     = Font(bold=True, color='FFFFFFFF')
TITLE  = Font(bold=True, sz=14, color='FFFFD500')
YF     = Font(bold=True, color='FFFFFF00')
BD     = Border(*[Side('thin', color='FFBFBFBF')] * 4)
CEN    = Alignment('center', 'center', wrap_text=True)
LEFT   = Alignment('left', 'center')

def put(ws, r, c, v, fill=None, font=None, fmt=None, al=CEN):
    x = ws.cell(row=r, column=c, value=v)
    if fill: x.fill = fill
    if font: x.font = font
    if fmt:  x.number_format = fmt
    x.alignment = al; x.border = BD
    return x

def band(ws, r, c1, c2, text, fill, font):
    ws.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)
    put(ws, r, c1, text, fill, font)
    for c in range(c1, c2 + 1): ws.cell(row=r, column=c).fill = fill; ws.cell(row=r, column=c).border = BD

def polish(ws, tab, last_col, title_rows):
    """Hoàn thiện hình thức: bỏ lưới, màu tab, khổ in, lặp tiêu đề khi in."""
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = tab
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr = openpyxl.worksheet.properties.PageSetupProperties(fitToPage=True)
    ws.print_title_rows = '1:%d' % title_rows
    ws.print_options.horizontalCentered = True
    ws.page_margins.left = ws.page_margins.right = 0.3
    ws.row_dimensions[1].height = 26

wb = openpyxl.Workbook(); wb.remove(wb.active)

# ══════════════════════════════════════════════════════════════════
# SHEET 1 — VƯỢT TRỘI TN  (6 tiêu chí)
# ══════════════════════════════════════════════════════════════════
CT = [('5sao', '1. PHỤC VỤ 5 SAO'), ('dungHen', '2. ĐÚNG HẸN'),
      ('tayNghe', '3. TAY NGHỀ CHUẨN (LỖI IMEI LẶP LẠI)'), ('xldd', '4. XỬ LÝ DD1 LẦN'),
      ('tho5s', '5. THỢ CHUẨN 5S'), ('scdv', '6. SỬA CHỮA KHÁCH LẺ'),
      ('doi1', '7. CL 1 ĐỔI 1'), ('trondoi', '8. CL BH TRỌN ĐỜI')]
ws = wb.create_sheet('VƯỢT TRỘI TN')
NC = len(CT)
band(ws, 2, 2, 4 + NC + 2, 'ĐÁNH GIÁ VƯỢT TRỘI TRƯỞNG NHÓM / QUẢN LÝ DỊCH VỤ — LŨY KẾ T1–T10/2026', NAVY, WF)
for c, t in ((2, 'Tên Siêu Thị'), (3, 'Mã Nhân Viên'), (4, 'Tên Nhân Viên')):
    ws.merge_cells(start_row=3, start_column=c, end_row=5, end_column=c); put(ws, 3, c, t, GREEN, Font(bold=True))
OV = 5                                    # khối lũy kế: 5 .. 5+NC+1
band(ws, 3, OV, OV + NC + 1, 'XẾP HẠNG ĐẾN HIỆN TẠI (LŨY KẾ T1–T10)', GREEN, Font(bold=True))
for i, (_, lb) in enumerate(CT):
    ws.merge_cells(start_row=4, start_column=OV + i, end_row=4, end_column=OV + i); put(ws, 4, OV + i, lb, GREEN, Font(bold=True, sz=9))
    put(ws, 5, OV + i, 'ĐIỂM', GREEN, Font(bold=True, sz=9))
put(ws, 4, OV + NC, 'TỔNG ĐIỂM', GREEN, Font(bold=True)); put(ws, 5, OV + NC, '', GREEN)
put(ws, 4, OV + NC + 1, 'XẾP HẠNG', GREEN, Font(bold=True)); put(ws, 5, OV + NC + 1, '', GREEN)
M0, BW = OV + NC + 2, NC * 3 + 2           # cột bắt đầu tháng 1, bề rộng 1 tháng
for k in MONTHS:
    b = M0 + BW * (k - 1)
    band(ws, 3, b, b + BW - 1, f'THÁNG {k}',
         ORANGE if k == 8 else BLUE, Font(bold=True))
    for i, (_, lb) in enumerate(CT):
        band(ws, 4, b + 3 * i, b + 3 * i + 2, lb, GREY, Font(bold=True, sz=8))
        for j, h in enumerate(('KPI', 'KẾT QUẢ', 'ĐIỂM')): put(ws, 5, b + 3 * i + j, h, GREY, Font(bold=True, sz=8))
    put(ws, 4, b + NC * 3, 'TỔNG ĐIỂM', GREY, Font(bold=True, sz=8)); put(ws, 5, b + NC * 3, '', GREY)
    put(ws, 4, b + NC * 3 + 1, 'XẾP HẠNG', GREY, Font(bold=True, sz=8)); put(ws, 5, b + NC * 3 + 1, '', GREY)

def fmt_of(c):  return '#,##0' if c == 'scdv' else ('0.00%' if c in ('dungHen', 'tayNghe', 'xldd', 'doi1', 'trondoi') else '0.00')
# Tháng đầu năm CHƯA ĐO -> điền sẵn cho file không trống, ĐÚNG ĐƠN VỊ của từng tiêu chí:
#   Đúng hẹn = 100% · Tay nghề chuẩn (IMEI lặp lại) = 100%  (cùng đơn vị % như T7–T8)
#   Thợ Chuẩn 5S = 10                                        (cùng thang điểm 10 như T7–T8)
FILL_TN = {'dungHen': (1.0, '0.00%'), 'tayNghe': (1.0, '0.00%'), 'tho5s': (10, '0.00')}
r = 6
_zi = 0
for m, t in sorted(TN.items(), key=lambda x: (x[1]['vung'], x[1]['xepHang'], x[1]['tinh'])):
    z = ZEBRA if _zi % 2 else None; _zi += 1
    put(ws, r, 2, t['tinh'], z, al=LEFT); put(ws, r, 3, m, z, Font(bold=True)); put(ws, r, 4, t['ten'], z, Font(bold=True), al=LEFT)
    for i, (c, _) in enumerate(CT): put(ws, r, OV + i, t['diemLK'].get(c, 0), CUMF, fmt='0')
    put(ws, r, OV + NC, t['tongDiem'], YELLOW, Font(bold=True), '0')
    put(ws, r, OV + NC + 1, f"{t['xepHang']} ({t['vung']})", YELLOW, Font(bold=True))
    for k in MONTHS:
        b = M0 + BW * (k - 1); mm = t['thang'].get('T%d' % k, {})
        for i, (c, _) in enumerate(CT):
            tc = (mm.get('tc') or {}).get(c)
            kpi = tc['kpi'] if tc else None
            kq  = tc['kq']  if tc else None
            f   = fmt_of(c)
            if tc and kpi is None and kq is None and c in FILL_TN:   # tháng chưa đo
                kpi, f = FILL_TN[c][0], FILL_TN[c][1]
                kq = kpi
            put(ws, r, b + 3 * i,     kpi, z, fmt=f)
            put(ws, r, b + 3 * i + 1, kq,  z, fmt=f)
            put(ws, r, b + 3 * i + 2, tc['d'] if tc else None, z, fmt='0')
        put(ws, r, b + NC * 3, mm.get('tong'), z, Font(bold=True), '0')
        put(ws, r, b + NC * 3 + 1, mm.get('hang'), z, fmt='0')
    r += 1
ws.column_dimensions['B'].width = 20; ws.column_dimensions['C'].width = 11; ws.column_dimensions['D'].width = 24
for c in range(OV, OV + NC + 2): ws.column_dimensions[get_column_letter(c)].width = 11
for k in MONTHS:
    b = M0 + BW * (k - 1)
    for c in range(b, b + BW): ws.column_dimensions[get_column_letter(c)].width = 10
    ws.column_dimensions.group(get_column_letter(b), get_column_letter(b + BW - 1), outline_level=1)
ws.freeze_panes = 'E6'; ws.row_dimensions[3].height = 20; ws.row_dimensions[4].height = 36
polish(ws, 'FF00B050', last_col=M0 + BW * 8 - 1, title_rows=5)

# ══════════════════════════════════════════════════════════════════
# SHEET 2 — VƯỢT TRỘI NV.  (tại nhà ở trên, tại kho ở dưới)
# ══════════════════════════════════════════════════════════════════
ws = wb.create_sheet('VƯỢT TRỘI NV.')
HDR = ['Tên Khu Vực', 'Mã Siêu Thị', 'Tên Siêu Thị', 'Mã Nhân Viên', 'Tên Nhân Viên',
       'Tên Chức Vụ', 'Tên Phòng Ban']
NCV = ['1. Không góp ý khiếu nại', '2. Tỷ lệ tiếp cận >= trung bình kho NV đang làm việc hiện tại',
       '3. Xử lý dứt điểm 1 lần']
TAIL = ('THU NHẬP', 'ĐIỂM', 'XẾP HẠNG', 'VƯỢT TRỘI')
OV = 2 + len(HDR)          # cột bắt đầu khối lũy kế
M0, BW = OV + 7, 13        # cột bắt đầu Tháng 1 · bề rộng 1 tháng
LAST = M0 + BW * 8 - 1

band(ws, 1, 2, LAST, 'ĐÁNH GIÁ VƯỢT TRỘI NHÂN VIÊN BẢO HÀNH — LŨY KẾ 10 THÁNG ĐẦU NĂM (T1–T10/2026)', NAVY, TITLE)

def nv_header(r0, cum_label):
    """Ghi khối tiêu đề 3 dòng bắt đầu từ r0 (dùng lại cho phần Tại kho)."""
    for i, h in enumerate(HDR):
        ws.merge_cells(start_row=r0, start_column=2 + i, end_row=r0 + 2, end_column=2 + i)
        put(ws, r0, 2 + i, h, BLUE, YF)
    band(ws, r0, OV, OV + 6, cum_label, BLUE, YF)
    for i, lb in enumerate(NCV):
        ws.merge_cells(start_row=r0 + 1, start_column=OV + i, end_row=r0 + 1, end_column=OV + i)
        put(ws, r0 + 1, OV + i, lb, BLUE, YF)
        put(ws, r0 + 2, OV + i, 'ĐIỂM', BLUE, YF)
    for i, lb in enumerate(TAIL):
        ws.merge_cells(start_row=r0 + 1, start_column=OV + 3 + i, end_row=r0 + 2, end_column=OV + 3 + i)
        put(ws, r0 + 1, OV + 3 + i, lb, BLUE, YF)
    for k in MONTHS:
        b = M0 + BW * (k - 1)
        band(ws, r0, b, b + BW - 1, f'THÁNG {k}',
             ORANGE if k == 8 else MONTHHDR, Font(bold=True, color='FF13233F'))
        for i, lb in enumerate(NCV):
            band(ws, r0 + 1, b + 3 * i, b + 3 * i + 2, lb, GREY, Font(bold=True, sz=8))
            for j, h in enumerate(('KPI', 'KẾT QUẢ', 'ĐIỂM')):
                put(ws, r0 + 2, b + 3 * i + j, h, GREY, Font(bold=True, sz=8))
        for i, lb in enumerate(TAIL):
            ws.merge_cells(start_row=r0 + 1, start_column=b + 9 + i, end_row=r0 + 2, end_column=b + 9 + i)
            put(ws, r0 + 1, b + 9 + i, lb, GREY, Font(bold=True, sz=8))
    ws.row_dimensions[r0].height = 20
    ws.row_dimensions[r0 + 1].height = 40

nv_header(2, 'XẾP HẠNG HIỆN TẠI (LŨY KẾ T1–T10)')

INC = D.get('INC', {})

# ══════════════════════════════════════════════════════════════════
# KẾT QUẢ TỪNG THÁNG  (quy luật lấy đúng từ file 6 tháng của anh Thu — khớp 798/798 ô)
#   • XẾP HẠNG tháng  = hạng theo ĐIỂM tháng đó trong kho (thi đấu, đồng hạng)
#   • VƯỢT TRỘI tháng = đủ 6/6 điểm VÀ trong top quota kho, ưu tiên thu nhập tháng đó
#     Quota tháng = round(30% × tổng NV kho)  — chốt anh Thu 28/08 (làm tròn gần nhất)
#     T7–T8 chưa có bảng lương → đánh dấu HẾT người đủ 6/6 điểm, không giới hạn quota
# ══════════════════════════════════════════════════════════════════
NOPAY = {10}
_byk = defaultdict(list)
for _m, _n in NV.items(): _byk[_n['kho']].append(_m)
RANK_M, VT_M = {}, {}
for _k, _mem in _byk.items():
    _q = round(len(_mem) * 0.30)
    for _mth in MONTHS:
        _t = 'T%d' % _mth
        _pts = {x: NV[x]['thang'][_t]['diem'] for x in _mem if _t in NV[x]['thang']}
        for x, v in _pts.items():
            RANK_M[(x, _mth)] = 1 + sum(1 for y in _pts.values() if y > v)
        _full = [x for x, v in _pts.items() if v == 6]
        if _mth in NOPAY:
            _win = set(_full)
        else:
            _full.sort(key=lambda x: -(INC.get('%s|T%d' % (x, _mth)) or 0))
            _win = set(_full[:_q])
        for x in _win: VT_M[(x, _mth)] = True

_bykk = defaultdict(list)
for _m, _t in TK.items(): _bykk[_t['kho']].append(_m)
RANK_TK, VT_TK = {}, {}
for _k, _mem in _bykk.items():
    _q = round(len(_mem) * 0.30)
    for _mth in MONTHS:
        _pay = {x: INC.get('%s|T%d' % (x, _mth)) for x in _mem}
        _pay = {x: v for x, v in _pay.items() if v}
        if not _pay: continue
        for i, x in enumerate(sorted(_pay, key=lambda y: -_pay[y])):
            RANK_TK[(x, _mth)] = i + 1
            if i < _q: VT_TK[(x, _mth)] = True

def row_nv(r, n, ma_, vt, tainha=True, z=None):
    """Ghi 1 dòng nhân viên. z = nền kẻ sọc (zebra)."""
    put(ws, r, 2, 'Vùng Trung Bộ' if n['vung'] == 'VTB' else 'Vùng Duyên Hải', z, al=LEFT)
    put(ws, r, 3, n['kho'], z); put(ws, r, 4, n['tinh'], z, al=LEFT)
    put(ws, r, 5, ma_, z, Font(bold=True)); put(ws, r, 6, n['ten'], z, Font(bold=True), al=LEFT)
    put(ws, r, 7, n.get('chucVu', ''), z)
    put(ws, r, 8, 'Bảo Hành Sửa Chữa Tại Nhà' if tainha else 'Bảo Hành Sửa Chữa Tại Kho', z, al=LEFT)
    if tainha:
        for i, c in enumerate(('khieuNai', 'tiepCan', 'xldd')):
            put(ws, r, OV + i, n['diemLK'].get(c, 0), CUMF, fmt='0')
        put(ws, r, OV + 3, n.get('thuNhap') or None, CUMF, fmt='#,##0')
        put(ws, r, OV + 4, n['diem'], CUMF, Font(bold=True, sz=12, color='FF0B2E63'), '0')
        put(ws, r, OV + 5, n['xepHang'], CUMF, fmt='0')
    else:
        for i in range(3): put(ws, r, OV + i, None, CUMF)
        put(ws, r, OV + 3, n.get('thuNhap') or None, CUMF, fmt='#,##0')
        put(ws, r, OV + 4, None, CUMF)
        put(ws, r, OV + 5, n.get('hangThuNhap'), CUMF, fmt='0')
    put(ws, r, OV + 6, 'VƯỢT TRỘI' if vt else None,
        YELLOW if vt else CUMF, Font(bold=True, color='FF7A5C00') if vt else None)
    for k in MONTHS:
        b = M0 + BW * (k - 1)
        if tainha:
            mm = n['thang'].get('T%d' % k)
            if not mm: continue
            tc = mm['tc']
            put(ws, r, b, 0, z, fmt='0')
            put(ws, r, b + 1, tc['khieuNai']['kq'], z, fmt='0')
            put(ws, r, b + 2, tc['khieuNai']['d'], z, fmt='0')
            put(ws, r, b + 3, tc['tiepCan']['kpi'], z, fmt='0.0%')
            put(ws, r, b + 4, tc['tiepCan']['kq'], z, fmt='0.0%')
            put(ws, r, b + 5, tc['tiepCan']['d'], z, fmt='0')
            put(ws, r, b + 6, 0, z, fmt='0')
            put(ws, r, b + 7, tc['xldd']['kq'], z, fmt='0')
            put(ws, r, b + 8, tc['xldd']['d'], z, fmt='0')
            put(ws, r, b + 9, INC.get(f'{ma_}|T{k}') or None, z, fmt='#,##0')
            put(ws, r, b + 10, mm['diem'], z, Font(bold=True), '0')
            put(ws, r, b + 11, RANK_M.get((ma_, k)), z, fmt='0')
            v = VT_M.get((ma_, k))
        else:
            pay = INC.get(f'{ma_}|T{k}')
            if not pay: continue
            put(ws, r, b + 9, pay, z, fmt='#,##0')
            put(ws, r, b + 11, RANK_TK.get((ma_, k)), z, fmt='0')
            v = VT_TK.get((ma_, k))
        put(ws, r, b + 12, 'VƯỢT TRỘI' if v else None,
            YELLOW if v else z, Font(bold=True, sz=8, color='FF7A5C00') if v else None)

r = 5
band(ws, r, 2, LAST, '■ NHÂN VIÊN BẢO HÀNH TẠI NHÀ — xét 3 tiêu chí (2đ/tiêu chí/tháng), quota Vượt Trội 30% mỗi kho', GREEN, WF)
r += 1
i = 0
for ma_, n in sorted(NV.items(), key=lambda x: (x[1]['vung'], x[1]['tinh'], x[1]['xepHang'])):
    row_nv(r, n, ma_, ma_ in FINAL, True, ZEBRA if i % 2 else None); r += 1; i += 1
FREEZE_AT = r
r += 1
band(ws, r, 2, LAST, '■ NHÂN VIÊN BẢO HÀNH TẠI KHO — KHÔNG xét 3 tiêu chí, chỉ xét TOP 30% thu nhập cao nhất kho', GREEN, WF)
r += 1
nv_header(r, 'XẾP HẠNG HIỆN TẠI (THEO THU NHẬP T1–T6)')      # lặp lại tiêu đề cho khối tại kho
r += 3
i = 0
for ma_, t in sorted(TK.items(), key=lambda x: (x[1]['kho'], x[1]['hangThuNhap'])):
    row_nv(r, t, ma_, t['vuotTroi'], False, ZEBRA if i % 2 else None); r += 1; i += 1

for col, wd in (('B', 15), ('C', 11), ('D', 18), ('E', 11), ('F', 24), ('G', 15), ('H', 26)):
    ws.column_dimensions[col].width = wd
for c in range(OV, OV + 7): ws.column_dimensions[get_column_letter(c)].width = 11
for k in MONTHS:                       # gom nhóm cột từng tháng để anh Thu thu/mở nhanh
    b = M0 + BW * (k - 1)
    for c in range(b, b + BW): ws.column_dimensions[get_column_letter(c)].width = 9.5
    ws.column_dimensions.group(get_column_letter(b), get_column_letter(b + BW - 1), outline_level=1)
ws.freeze_panes = get_column_letter(OV) + '5'
polish(ws, 'FF00B0F0', last_col=LAST, title_rows=4)
# ══════════════════════════════════════════════════════════════════
# SHEET 3 — GHI CHÚ
# ══════════════════════════════════════════════════════════════════
ws = wb.create_sheet('GHI CHÚ')
notes = [
 ('ĐÁNH GIÁ VƯỢT TRỘI 2026 — LŨY KẾ 10 THÁNG ĐẦU NĂM (T1–T10)', ''),
 ('Nguồn dữ liệu', 'Google Sheet "VTB - DH DATA 2026" (11 tab) + Danh sách nhân sự bảo hành 158 người'),
 ('Kỳ đánh giá', 'Lũy kế T1–T10/2026 — Tháng 10 chốt data tới 25/10/2026 (chưa hết tháng).'),
 ('', ''),
 ('TRƯỞNG NHÓM / QLDV — 6 tiêu chí',
  '5 Sao (4đ) · Đúng hẹn (2đ) · Tay nghề chuẩn (2đ) · XLDĐ 1 lần (2đ) · Thợ Chuẩn 5S (2đ) · SCDV (2đ từ T1–T6, 4đ từ T7). Xếp hạng riêng VTB / VDH.'),
 ('Đúng hẹn / Tay nghề / Thợ 5S', 'T1–T6 KPI ghi "Không tính, mặc định có điểm" → tính ĐẠT. Từ T7 chấm theo KPI thật (Đúng hẹn 97% T7, 98% T8).'),
 ('Ô KPI/Kết quả tháng chưa đo', 'Điền sẵn cho file không trống, đúng đơn vị từng tiêu chí: Đúng hẹn = 100%, Tay nghề chuẩn = 100% (thang %), Thợ Chuẩn 5S = 10 (thang điểm 10). Không ảnh hưởng điểm — các tháng này đều tính ĐẠT.'),
 ('Cột KPI của NV', 'Tiêu chí "Không góp ý khiếu nại" và "Xử lý dứt điểm 1 lần" có KPI = 0 (nghĩa là không được phép có lỗi nào).'),
 ('', ''),
 ('NHÂN VIÊN TẠI NHÀ — 3 tiêu chí (2đ mỗi tiêu chí/tháng)',
  '1. Không góp ý/khiếu nại · 2. Tỷ lệ tiếp cận ≥ trung bình kho · 3. Không lỗi XLDĐ 1 lần'),
 ('Ngưỡng "trung bình kho"', 'Trung bình cộng tỷ lệ tiếp cận của các NV ĐANG XÉT trong kho, tính riêng từng tháng.'),
 ('Tháng có đi làm', 'Có thu nhập tháng đó (T1–T6). T7–T8 chưa có bảng lương → căn cứ có phát sinh dữ liệu.'),
 ('Thiếu số tiếp cận', 'Chỉ tiêu chí Tiếp cận bị 0đ; Khiếu nại và XLĐ1L vẫn chấm bình thường.'),
 ('Khiếu nại tính vào điểm', 'Chỉ tính phiếu ĐÃ quy trách nhiệm (có Phòng ban Vi phạm). Phiếu để trống phòng ban không trừ điểm.'),
 ('Điều kiện xét', 'Tối thiểu 5 tháng có dữ liệu.'),
 ('Quota Vượt Trội', '30% mỗi kho (làm tròn gần nhất), xếp theo tổng điểm lũy kế; bằng điểm xét thêm thu nhập.'),
 ('Cột XẾP HẠNG từng tháng', 'Hạng theo ĐIỂM của tháng đó trong kho (đồng hạng khi bằng điểm).'),
 ('Cột VƯỢT TRỘI từng tháng', 'Đủ 6/6 điểm tháng đó VÀ nằm trong quota 30% của kho, ưu tiên người thu nhập tháng đó cao hơn. Tháng 7–8 chưa có bảng lương nên đánh dấu hết người đủ 6/6 điểm.'),
 ('NV tại kho theo tháng', 'Mỗi tháng ghi thu nhập, hạng thu nhập trong kho và đánh dấu top 30%. Tháng 7–8 để trống vì chưa có bảng lương.'),
 ('Bảo lưu kết quả đã chốt', 'ĐIỂM T1–T6 lấy nguyên từ bảng 6 tháng đầu năm đã duyệt, không tính lại. Từ T7 chấm theo rule. Danh hiệu Vượt Trội xét lại theo điểm lũy kế tới tháng mới nhất.'),
 ('', ''),
 ('NHÂN VIÊN TẠI KHO', 'Không xét 3 tiêu chí. Xét TOP 30% thu nhập cao nhất kho (thu nhập lũy kế T1–T6).'),
 ('', ''),
 ('KẾT QUẢ', f'NV tại nhà: {len(NV)} người — {len(FINAL)} đạt Vượt Trội ({len(FINAL)/len(NV)*100:.1f}%). '
             f'Trưởng nhóm/QLDV: {len(TN)}. NV tại kho: {len(TK)} — {sum(1 for x in TK.values() if x["vuotTroi"])} đạt.'),
 ('Đối chiếu file 6 tháng', 'Nhân viên khớp 99,62% (1299/1304 ô) · Trưởng nhóm khớp 98,72% (385/390 ô). '
                            'Chênh lệch còn lại do Google Sheet đã cập nhật lại số so với thời điểm chốt file cũ.'),
]
put(ws, 1, 2, notes[0][0], NAVY, WF, al=LEFT); ws.merge_cells('B1:C1')
for i, (a, b) in enumerate(notes[1:], start=3):
    put(ws, i, 2, a, GREY if a else None, Font(bold=True) if a else None, al=LEFT)
    put(ws, i, 3, b, al=Alignment('left', 'center', wrap_text=True))
ws.column_dimensions['B'].width = 42; ws.column_dimensions['C'].width = 118

ws.sheet_view.showGridLines = False
ws.sheet_properties.tabColor = 'FFB07A00'
ws.page_setup.orientation = 'portrait'

OUT = 'VUOT TROI 2026 - 10 THANG DAU NAM BHSC.xlsx'
wb.save(OUT)
print(f"→ {OUT}")
print(f"   TN {len(TN)} | NV tại nhà {len(NV)} ({len(FINAL)} VT) | NV tại kho {len(TK)} ({sum(1 for x in TK.values() if x['vuotTroi'])} VT)")
