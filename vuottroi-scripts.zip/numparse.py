# -*- coding: utf-8 -*-
"""Bộ đọc số CHỐNG NHẦM DẤU — dùng chung cho mọi tab của Google Sheet."""
import re

def num(v, kind='auto'):
    """kind: 'money' (VND, luôn số nguyên) | 'rate' (tỷ lệ/điểm, <1000) | 'auto'"""
    if v is None: return None
    if isinstance(v, bool): return None
    if isinstance(v, (int, float)): return float(v)
    s = str(v).strip()
    if not s: return None
    pct = s.endswith('%')
    s = s.replace('%', '').replace('\xa0', '').replace(' ', '').replace('đ', '').replace('VND', '')
    s = s.replace('(', '-').replace(')', '')
    if not re.fullmatch(r'-?[\d.,]+', s): return None
    neg = s.startswith('-'); s = s.lstrip('-')
    has_c, has_d = ',' in s, '.' in s

    if has_c and has_d:                       # có cả 2 -> dấu XUẤT HIỆN SAU CÙNG là thập phân
        dec = ',' if s.rfind(',') > s.rfind('.') else '.'
        s = s.replace(',' if dec == '.' else '.', '').replace(dec, '.')
    elif has_c or has_d:
        sep = ',' if has_c else '.'
        parts = s.split(sep)
        tail = parts[-1]
        if len(parts) > 2:                    # 11.943.000 -> chắc chắn phân cách nghìn
            s = s.replace(sep, '')
        elif len(tail) == 3 and len(parts[0]) <= 3:
            # 1 dấu + đúng 3 chữ số sau -> NHẬP NHẰNG, quyết theo ngữ cảnh cột
            s = s.replace(sep, '') if kind == 'money' else s.replace(sep, '.')
        elif len(tail) == 3 and kind == 'money':
            s = s.replace(sep, '')
        else:
            s = s.replace(sep, '.')           # 0,45 / 99.2 -> thập phân
    try: x = float(s)
    except ValueError: return None
    if neg: x = -x
    return x / 100 if pct else x
