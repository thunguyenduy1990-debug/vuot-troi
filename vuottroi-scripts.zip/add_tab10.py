#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CHÈN TAB 10 "VƯỢT TRỘI" vào web KẾT QUẢ VẬN HÀNH BHSC CE.

Chạy SAU MỖI LẦN build lại dashboard (build2.js) — script tự nhận biết đã chèn
hay chưa nên chạy nhiều lần vẫn an toàn (idempotent).

    python3 add_tab10.py [index.html]

Cần cùng thư mục: vuottroi-tab.js · vuottroi-tab.css · slide_vt.js
"""
import re, sys, os

HTML = sys.argv[1] if len(sys.argv) > 1 else 'index.html'
JS, CSS = 'vuottroi-tab.js', 'vuottroi-tab.css'
MARK = '/* __TAB10_VUOT_TROI__ */'

for f in (HTML, JS, CSS):
    if not os.path.exists(f): sys.exit(f'THIẾU FILE: {f}')

html = open(HTML, encoding='utf-8').read()
js   = open(JS,   encoding='utf-8').read()
css  = open(CSS,  encoding='utf-8').read()
n0 = len(html)

# ── gỡ bản cũ nếu có (để chạy lại được nhiều lần) ────────────────────────
# Dùng REGEX cho MỌI bước gỡ — chuỗi khớp cứng từng bị lệch dấu xuống dòng.
if MARK in html or 'id="m9"' in html:
    html = re.sub(r'\n?<style>\s*%s.*?</style>' % re.escape(MARK), '', html, flags=re.S)
    html = re.sub(r'\n?<script>\s*%s.*?</script>' % re.escape(MARK), '', html, flags=re.S)
    html = re.sub(r'\n?\s*<section class="module" id="m9"[^>]*></section>', '', html)
    html = re.sub(r',\s*\{\s*id:"m9",[^}]*\}', '', html)
    html = re.sub(r',\s*renderM9\s*\]', ']', html)
    # slide PPT: cắt theo VỊ TRÍ (regex từng hỏng vì số dòng trống cuối khối thay đổi)
    _i = html.find('/* ---------- 13 · VƯỢT TRỘI')
    if _i >= 0:
        _j = html.find('return SL;', _i)
        assert _j > _i, 'không tìm thấy "return SL;" sau khối slide cũ'
        _k = html.rfind('\n', _i, _j)          # lùi về đầu dòng chứa return SL;
        html = html[:html.rfind('\n', 0, _i) + 1] + html[_k + 1:]
    for nm, c in (('panel m9', html.count('id="m9"')), ('MODULES m9', html.count('ten:"VƯỢT TRỘI"')),
                  ('renderM9', html.count('renderM9')), ('slide', html.count('id: "vuottroi"'))):
        assert c == 0, f'gỡ bản cũ THẤT BẠI: còn {c} chỗ "{nm}" — cấu trúc web đã đổi'
    print('· đã gỡ sạch bản tab 10 cũ')

steps = []
def sub1(old, new, label):
    global html
    n = html.count(old)
    assert n == 1, f'ANCHOR "{label}" xuất hiện {n} lần (cần đúng 1) — cấu trúc web đã đổi, phải sửa script'
    html = html.replace(old, new, 1); steps.append(label)

# 1) panel chứa nội dung tab
sub1('<section class="module" id="m8" role="tabpanel" hidden></section>',
     '<section class="module" id="m8" role="tabpanel" hidden></section>\n'
     '  <section class="module" id="m9" role="tabpanel" hidden></section>',
     'panel #m9')

# 2) thêm vào danh sách tab
sub1('{id:"m8", ten:"HỎI ĐÁP",                 icon:"message",        lk:"tab.m8"}\n];',
     '{id:"m8", ten:"HỎI ĐÁP",                 icon:"message",        lk:"tab.m8"},\n'
     '  {id:"m9", ten:"VƯỢT TRỘI",           icon:"trophy",         lk:"tab.m9"}\n];',
     'MODULES')

# 3) đăng ký hàm dựng màn hình
sub1('const RENDERERS=[renderM0,renderM1,renderM2,renderM3,renderM4,renderM5,renderM6,renderM7,renderM8];',
     'const RENDERERS=[renderM0,renderM1,renderM2,renderM3,renderM4,renderM5,renderM6,renderM7,renderM8,renderM9];',
     'RENDERERS')

# 4) CSS — chèn trước </head>
# (chuỗi "</head>" còn nằm trong thư viện xlsx nhúng sẵn → phải dùng mốc dài hơn)
sub1('</style>\n</head>\n<body>', f'</style>\n<style>{MARK}\n{css}\n</style>\n</head>\n<body>', 'CSS')

# 5) JS — chèn TRƯỚC khối khai báo RENDERERS để renderM9 tồn tại khi chạy tới
i = html.index('const RENDERERS=[renderM0')
j = html.rindex('<script>', 0, i)
html = html[:j] + f'<script>{MARK}\n{js}\n</script>\n' + html[j:]
steps.append('JS module')

# 6) SLIDE VƯỢT TRỘI trong PowerPoint (PDF thì tự có vì window.print() vẽ mọi tab)
slide = open('slide_vt.js', encoding='utf-8').read() if os.path.exists('slide_vt.js') else None
if slide:
    n = html.count('\n  return SL;')
    assert n == 1, f'ANCHOR "return SL" xuất hiện {n} lần'
    html = html.replace('\n  return SL;', '\n' + slide + '\n  return SL;', 1)
    steps.append('slide PPT')
else:
    print('· không thấy slide_vt.js — bỏ qua slide PowerPoint')

# ── kiểm tra sau khi chèn ────────────────────────────────────────────────
assert html.count('id="m9"') == 1,        'lỗi: panel m9 không đúng 1'
assert html.count('renderM9') >= 2,       'lỗi: renderM9 chưa được đăng ký'
assert html.count('ten:"VƯỢT TRỘI"') == 1, 'lỗi: tab VƯỢT TRỘI không đúng 1'
if slide: assert html.count('id: "vuottroi"') == 1, 'lỗi: slide Vượt Trội không đúng 1'

open(HTML, 'w', encoding='utf-8').write(html)
print('Đã chèn:', ' · '.join(steps))
print(f'{HTML}: {n0/1024/1024:.2f} MB → {len(html)/1024/1024:.2f} MB')
print('\nNhớ đặt cùng thư mục web 3 file:')
print('   vuottroi.json · VUOT-TROI-2026.xlsx · DATA-NGUON-VUOT-TROI.xlsx')
